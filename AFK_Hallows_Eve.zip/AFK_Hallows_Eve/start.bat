@echo off
chcp 65001 >NUL
setlocal
title AFK Hallow's Eve
cd /d "%~dp0"

set "PY="
py -3 --version 1>NUL 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY python --version 1>NUL 2>&1
if not defined PY if not errorlevel 1 set "PY=python"
if defined PY goto menu
echo Python was not found. Run install_requirements.bat first.
echo 找不到 Python。请先运行 install_requirements.bat。
pause
exit /b

:menu
cls
echo ==========================================================
echo   AFK Hallow's Eve  -  choose what to run / 选择要运行的功能
echo ==========================================================
echo   1  Everything: Hallow's Eve + Selene shop + rebirth
echo      全部：万圣夜 + Selene 商店 + 自动重生
echo   2  Hallow's Eve only            只运行万圣夜
echo   3  Selene shop only             只运行 Selene 商店
echo   4  Everything, no auto rebirth  全部，但不自动重生
echo.
echo   5  Test: check screen reading   测试：检查屏幕识别 (--sample)
echo   6  Test: Selene shop (shop must be OPEN)
echo      测试：Selene 商店（商店必须是打开的）(--shop-sample)
echo   7  Try one rebirth now          立即尝试一次重生
echo   0  Exit                         退出
echo ==========================================================
set "C="
set /p "C=Number / 输入数字: "
if "%C%"=="1" set "ARGS="& goto run
if "%C%"=="2" set "ARGS=--hallows-only"& goto run
if "%C%"=="3" set "ARGS=--shop-only"& goto run
if "%C%"=="4" set "ARGS=--no-rebirth"& goto run
if "%C%"=="5" set "ARGS=--sample"& goto run
if "%C%"=="6" set "ARGS=--shop-sample"& goto run
if "%C%"=="7" set "ARGS=--rebirth-now"& goto run
if "%C%"=="0" exit /b
goto menu

:run
echo.
echo Running / 正在运行: %PY% afk_hallows_eve.py %ARGS%
echo Stop with Ctrl+C / 按 Ctrl+C 停止
echo.
%PY% afk_hallows_eve.py %ARGS%
echo.
echo Finished / 已结束.
pause
goto menu
