﻿AFK 万圣夜脚本 - Fish an Anime RNG (Roblox)
====================================================

功能
  - 万圣夜 (Hallow's Eve)：活动期间，自动拿着快捷栏第 2 格的角色。
    该角色获得 Dracula 突变后，自动换到第 3 格、第 4 格……
    遇到药水格时停止。活动结束后，自动把角色收起来。
  - Selene 商店：Selene 的提示出现时，自动打开她的商店，购买所有用现金或宝石
    购买的物品。显示 OUT OF STOCK（售罄）或 OWNED（已拥有）的物品会被跳过。
  - 自动重生：每小时打开一次重生菜单并点击 Rebirth!。
    如果现金不够，会自动关闭弹出的 "Skip Rebirth" Robux 购买窗口。
  - 绝对不会花费 Robux。Robux 按钮和 Roblox 的 Buy（购买）按钮永远不会被点击。


安装（只需一次）
  1. 双击 install_requirements.bat（自动安装 Python、所需的库和 Tesseract OCR）。
     如果 Windows 提示"Windows 已保护你的电脑"，点击"更多信息" -> "仍要运行"。
     如果下载很慢或失败，安装程序会自动改用清华 / 阿里云国内镜像，请耐心等待。
  2. 把 afk_hallows_eve.py 和 start.bat 放在同一个文件夹里。
     tessdata 文件夹（Tesseract 的英文语言文件）也要放在一起，不要删除。


运行前请确认
  - 屏幕分辨率必须是 1920x1080，Roblox 窗口要全屏（最大化）。
  - 用正常的 Play（开始游戏）按钮启动 Roblox（窗口名称必须是 "Roblox"）。
  - 快捷栏必须放满（所有格子都要有东西）。脚本是按格子位置找角色的，
    读到药水时就知道角色已经结束了：
      * 第 1 格          = 钓鱼竿
      * 第 2 格          = 万圣夜的第一个角色
      * 第 3、4 格……     = 其他角色，紧接在后面，中间不能空格
      * 剩下的格子       = 药水（角色后面的格子全部放满）
    如果有空格子或者中间断开，脚本会提前停止，因为它无法拿起空格子。
  - Selene 商店：站在她出现时 "Selene's Store / Talk" 提示会显示的位置。


如何运行
  最简单：双击 start.bat，输入想运行的功能的数字即可。
  它和下面的命令功能完全一样。

  或者自己输入命令：
  打开文件夹，点击地址栏，输入  cmd  然后按回车。
  再输入下面任意一条命令并按回车。

  正常使用：
    py afk_hallows_eve.py                      全部开启：万圣夜 + Selene 商店 + 自动重生

  开关（选择要运行的功能）：
    py afk_hallows_eve.py --hallows-only       只运行万圣夜（不买 Selene 商店）
    py afk_hallows_eve.py --shop-only          只运行 Selene 商店（不管万圣夜）
    --no-rebirth                               加在任意命令后面，关闭自动重生
                                               例如  py afk_hallows_eve.py --shop-only --no-rebirth

  测试工具（运行一次后自动退出）：
    py afk_hallows_eve.py --sample             检查脚本能否正确识别活动和快捷栏。
                                               会保存 debug_*.png 图片供查看。
    py afk_hallows_eve.py --mutation-sample [突变名]
                                               显示脚本在角色上方读到的文字
                                               （例如 --mutation-sample dracula）。
    py afk_hallows_eve.py --shop-sample        在 Selene 商店打开时运行：显示会点击哪些按钮，
                                               以及读到的库存状态。
                                               会保存 debug_shop.png 和 debug_close.png。
    py afk_hallows_eve.py --shop-now           立即执行一次 Selene 商店购买。
    py afk_hallows_eve.py --rebirth-now        立即尝试一次重生。

  如果 "py" 不能用，请改用 "python"（反之亦然）。如果命令一下就结束、什么字都没有显示，
  那是 Windows 的微软商店快捷方式，不是真正的 Python：请用 "py" 或 start.bat。


如何停止
  在黑色窗口中按 Ctrl+C，或者把鼠标快速移到屏幕的任意一个角落（紧急停止）。


设置（可选 - 用记事本打开 afk_hallows_eve.py，在文件开头附近）
  FIRST_SLOT = 2           万圣夜第一个角色所在的快捷栏格子
  MUTATION_WORD = "dracula" 换到下一格之前要等待的突变
  REBIRTH_EVERY = 60 * 60  每次检查重生的间隔秒数（60*60 = 1 小时）
  BUY_CLICKS = 10          每个商店物品最多点击次数
  STOCK_CHECK = True       显示 OUT OF STOCK 时停止点击（False = 关闭）
  AUTO_FOCUS = True        按键前自动把 Roblox 窗口切到最前面
  TESSERACT_PATH           Tesseract OCR 的安装位置（一般不用改）


注意事项
  - 脚本在购买或重生时（大约 10-60 秒）不要动鼠标。
  - 重生达到 250 次（解锁 SACRIFICE 献祭）时，自动重生会自己停止，
    让你自己决定。
  - 可以和 Fish RNG Manager（多账号程序）一起使用：两者会自动轮流使用鼠标和键盘。
  - 使用宏可能违反 Roblox 的规则，风险自负。
