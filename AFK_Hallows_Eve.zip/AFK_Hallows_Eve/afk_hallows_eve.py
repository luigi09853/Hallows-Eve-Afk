"""
AFK helper: equips "Ada Smasher" while the "Hallow's Eve" event is running,
and unequips her when it isn't.

Setup (one time):
    pip install mss pillow pyautogui pytesseract opencv-python numpy
    Install Tesseract OCR: https://github.com/UB-Mannheim/tesseract/wiki
    (if it isn't on your PATH, set TESSERACT_PATH below)

Usage:
    python afk_hallows_eve.py --sample     # shows what the script sees (do this first)
    python afk_hallows_eve.py              # run everything: Hallow's Eve + Selene's store
    python afk_hallows_eve.py --mutation-sample [word]  # shows what it reads above your character
    python afk_hallows_eve.py --hallows-only # Hallow's Eve / Ada only (no shop)
    python afk_hallows_eve.py --shop-only    # Selene's store only (or run afk_selene_shop.py)
    python afk_hallows_eve.py --shop-sample  # with Selene's shop OPEN: shows what it would click
    python afk_hallows_eve.py --shop-now     # run the shop buyer once, right now
    python afk_hallows_eve.py --rebirth-now  # try one rebirth right now
    add --no-rebirth to any run to turn off the hourly rebirth check

Runs alongside Fish RNG Manager: start your main from the normal Roblox Play button (window
titled "Roblox"); the app's alts are titled "Roblox - name", so this script never touches them.
The two take turns with the mouse/keyboard automatically.

Keep the Roblox window focused while it runs. Move your mouse into a screen
corner (pyautogui failsafe) or press Ctrl+C in the terminal to stop.
"""

import os
import sys
import time
import difflib
import re
import io
import base64
import cv2
import numpy as np
import ctypes
from contextlib import contextmanager
try:
    from mss import MSS as mss      # newer mss
except ImportError:
    from mss import mss             # older mss
from PIL import Image, ImageOps
import pyautogui
import pytesseract

# ---------------- CONFIG (tuned for a 1920x1080 screen) ----------------
CHECK_INTERVAL = 2           # seconds between checks (start-to-start)
FIRST_SLOT = 2               # hotbar slot of the first character to mutate (Ada Smasher)
MUTATION_WORD = "dracula"    # the mutation to wait for; when seen, it moves to the next slot
MUTATION_REGION = (450, 215, 1350, 650)   # area around your character where its label shows
HOTBAR_LABEL_SCALE = 6        # how much the small hotbar label is enlarged before reading it
LABEL_ROWS = (935, 957)       # screen rows of the mutation label above a hotbar slot (below the stars)
LABEL_DARK = 45               # pixels darker than this count as the label's black outline
USE_WORLD_LABEL = True       # also read the label floating around your character (backup to the hotbar label)
MUTATION_CHECK_EVERY = 4     # seconds between mutation checks (while a character is held)
MUTATION_CONFIRM_READS = 2   # must be seen this many checks in a row before moving on

# Where the event name shows up on screen: (left, top, right, bottom).
# I can't see an active event in your screenshot, so adjust this to wherever
# "Hallow's Eve" appears (use --sample to save a crop and check it).
EVENT_REGION = (700, 85, 1220, 190)   # title + description + duration block
# Title strip only (the big colored event name); read separately for accuracy
TITLE_REGION = (780, 85, 1140, 128)

# Words that mean Hallow's Eve is running. Matching is fuzzy, so garbled OCR
# still counts. Once you see the event's description text, add distinctive
# words from it here (lowercase), e.g. "spooky", "candy".
TITLE_WORDS = ["hallows", "hallow's", "halloweve", "hallowseve"]
DESCRIPTION_WORDS = ["dracula"]
FUZZY_CUTOFF = 0.75          # (only used by older helper code)
STRONG_CUTOFF = 0.90         # title word this close to "hallows" counts on its own
MEDIUM_CUTOFF = 0.80         # this close only counts if "eve" is also read
EVENT_CONFIRM_READS = 2      # readings in a row before switching (stops one misread acting)

# Hotbar geometry (1920x1080): slot 2 starts at x=618, slots are ~85.6 px apart
HOTBAR_SLOT2_LEFT = 618
HOTBAR_PITCH = 85.6
HOTBAR_TOP, HOTBAR_BOTTOM, SLOT_WIDTH = 957, 1038, 81
BORDER_THICKNESS = 5         # px ring along the edge of the slot to inspect
BLUE_FRACTION = 0.25         # share of border pixels that must be the "held" blue

# ---------------- SELENE'S STORE (auto-buy) ----------------
HALLOWS_ENABLED = True       # Hallow's Eve / Ada Smasher logic (--shop-only turns this off)
SHOP_ENABLED = True          # Selene's store auto-buy (--hallows-only turns this off)
SHOP_CHECK_EVERY = 4         # seconds between looks for the "Selene's Store / Talk" prompt
SHOP_COOLDOWN = 600          # after a visit, ignore the prompt this long (she stays ~5 min)
OPEN_KEY_SCANCODE = 0x12     # "E" key, opens the shop when you're next to her
PROMPT_REGION = (900, 520, 1500, 720)    # where the "Selene's Store / Talk" prompt appears
SHOP_REGION = (400, 300, 1525, 790)      # the shop's item area (buy buttons are searched here only)
CLOSE_REGION = (1100, 100, 1800, 420)    # area searched for the shop's red X (wide on purpose)
OPEN_WAIT = 10               # seconds to wait for the shop to appear after pressing E (it can be slow)
BUY_CLICKS = 10              # clicks per cash/gem button (stock is limited, extra clicks do nothing)
BUY_CLICK_DELAY = 0.25
SCROLL_NOTCHES = 60          # mouse-wheel notches per scroll step (lower it if rows get skipped)
SCROLL_TOP_CLICKS = 1000     # wheel clicks upward when the shop opens, to be sure it's at the very top
MAX_SCROLL_STEPS = 14
CLICK_OFFSET_X = 55          # px to the RIGHT of the cash/gem icon to click (the icon itself isn't clickable)
SHOP_PASSES = 2              # walk the list twice (catch-message text can hide a button the first time)
MAX_CLICKS_PER_VISIT = 150   # hard safety cap
STOCK_CHECK = True           # stop clicking an item once it says "out of stock" / "sold out"
# Area read for stock text, relative to the cash/gem icon: (left, top, right, bottom) in pixels.
# Selene's shop prints "OUT OF STOCK" / "OWNED" across the bottom of the item card, above and to
# the right of the buy buttons. Check it with --shop-sample (yellow boxes).
STOCK_REGION_OFFSET = (-25, -110, 295, -32)
MATCH_THRESHOLD = 0.85
# NOTE: only the cash ($) and gem buttons are ever clicked. Robux buttons are never clicked.

# ---------------- AUTO REBIRTH ----------------
REBIRTH_ENABLED = True       # try to rebirth every REBIRTH_EVERY seconds (--no-rebirth turns it off)
REBIRTH_EVERY = 60 * 60      # 1 hour
REBIRTH_FIRST_AFTER = 30     # first try this many seconds after the script starts
REBIRTH_SIDE_BUTTON = (58, 425)          # the REBIRTH button on the left of the screen
REBIRTH_BTN_REGION = (450, 640, 1000, 810)   # where the green "Rebirth!" button appears
SACRIFICE_TEXT_REGION = (560, 805, 1360, 870)  # "Reach 250 Rebirths to unlock SACRIFICE!"
REBIRTH_POPUP_WAIT = 6       # seconds to watch for the "Skip Rebirth" Robux pop-up after clicking
# NOTE: only the green "Rebirth!" button is ever clicked. The pink Robux button next to it never is,
# and if Roblox's purchase pop-up opens, only its X is clicked (never Buy).

AUTO_FOCUS = True            # set False if you'd rather keep Roblox focused yourself
TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# -----------------------------------------------------------------------

os.environ.setdefault("OMP_THREAD_LIMIT", "1")   # keep OCR to one CPU thread so the game isn't starved

if TESSERACT_PATH:
    pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

pyautogui.FAILSAFE = True


# ---------------- taking turns with Fish RNG Manager ----------------
# Fish RNG Manager (the multi-account app) holds this same lock while it clicks/presses keys
# in an alt's window. This script holds it while it presses hotbar keys or shops at Selene,
# so the two never use the mouse/keyboard at the same time. Works fine without the app too.
_LOCK = None
try:
    _k32 = ctypes.WinDLL("kernel32")
    _k32.CreateMutexW.restype = ctypes.c_void_p
    _k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    _k32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    _k32.WaitForSingleObject.restype = ctypes.c_uint32
    _k32.ReleaseMutex.argtypes = [ctypes.c_void_p]
    _LOCK = _k32.CreateMutexW(None, False, "FishRNG_InputLock")
except Exception:
    _LOCK = None


@contextmanager
def my_turn(why=""):
    """Wait until Fish RNG Manager isn't using the mouse/keyboard, then hold them until done."""
    got = False
    if _LOCK:
        r = _k32.WaitForSingleObject(_LOCK, 0)
        if r not in (0, 0x80):
            print(f"  waiting for Fish RNG Manager to finish{' before ' + why if why else ''}...")
            r = _k32.WaitForSingleObject(_LOCK, 180_000)
        got = r in (0, 0x80)
        if got:
            time.sleep(0.2)          # let the app finish handing focus back
    try:
        yield
    finally:
        if got:
            _k32.ReleaseMutex(_LOCK)


def grab(region):
    l, t, r, b = region
    with mss() as sct:
        shot = sct.grab({"left": l, "top": t, "width": r - l, "height": b - t})
    return Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")


def _variants(img, scale):
    img = img.resize((img.width * scale, img.height * scale))
    gray = img.convert("L")
    yield "gray", gray
    yield "inverted", ImageOps.invert(gray)
    yield "bright_only", gray.point(lambda p: 255 if p > 170 else 0)
    yield "bright_inverted", gray.point(lambda p: 0 if p > 170 else 255)


def _ocr_variants(img, scale, psm):
    """Full read, every variant (used by --sample)."""
    out = {}
    for name, v in _variants(img, scale):
        out[name] = (v, pytesseract.image_to_string(v, config=f"--psm {psm}").lower())
    return out


def _fuzzy_has(text, words):
    tokens = re.findall(r"[a-z']+", text)
    for t in tokens:
        for w in words:
            if difflib.SequenceMatcher(None, t, w).ratio() >= FUZZY_CUTOFF:
                return True
    return False


def _clean_ocr(text):
    """OCR often reads l as 1 or I, o as 0, s as 5. Undo that before matching words."""
    t = text.lower()
    for a, b in (("1", "l"), ("|", "l"), ("0", "o"), ("5", "s"), ("’", "'"), ("`", "'")):
        t = t.replace(a, b)
    return t


def _title_word_score(text):
    """Best similarity of any word in `text` to "hallows" (only words that look the part)."""
    best = 0.0
    for tok in re.findall(r"[a-z']+", _clean_ocr(text)):
        tok2 = tok.replace("'", "")
        if len(tok2) < 6 or tok2[0] not in "hn":     # 'n' = a common misread of a stylised H
            continue
        for w in TITLE_WORDS:
            best = max(best, difflib.SequenceMatcher(None, tok2, w.replace("'", "")).ratio())
    return best


def _hallows_reason(title_text, body_text):
    """Why the text means Hallow's Eve is on, or "" if it doesn't."""
    both = title_text + " " + body_text
    score = _title_word_score(both)
    if score >= STRONG_CUTOFF:
        return f"title word ~ 'hallows' ({score:.2f})"
    clean = _clean_ocr(body_text)
    for w in DESCRIPTION_WORDS:
        if w in clean:
            return f"'{w}' in the description"
    if score >= MEDIUM_CUTOFF and re.search(r"\beve\b", _clean_ocr(both)):
        return f"title word ~ 'hallows' ({score:.2f}) + 'eve'"
    return ""


def event_active(save_debug=False):
    """(is_on, explanation). One reading only: main() requires a few in a row before acting."""
    if save_debug:
        body = _ocr_variants(grab(EVENT_REGION), 3, 6)
        title = _ocr_variants(grab(TITLE_REGION), 4, 7)
        for name, (im, _) in body.items():
            im.save(f"debug_event_{name}.png")
        for name, (im, _) in title.items():
            im.save(f"debug_title_{name}.png")
        title_text = " | ".join(t.strip() for _, t in title.values())
        body_text = " | ".join(t.strip() for _, t in body.values())
        why = _hallows_reason(title_text, body_text)
        decision = why or "not Hallow's Eve"
        return bool(why), f"TITLE: {title_text}\nBODY: {body_text}\nDECISION: {decision}"

    # Fast path for the loop: small title strip first, stop at the first hit.
    title_text = ""
    for name, v in _variants(grab(TITLE_REGION), 3):
        if name not in ("gray", "bright_only"):
            continue
        title_text += " " + pytesseract.image_to_string(v, config="--psm 7").lower()
        why = _hallows_reason(title_text, "")
        if why:
            return True, f"{why} | read: {title_text.strip()!r}"
    # Then the description block (title + "dracula" in the description)
    body_text = ""
    for name, v in _variants(grab(EVENT_REGION), 2):
        if name not in ("gray", "bright_only"):
            continue
        body_text += " " + pytesseract.image_to_string(v, config="--psm 6").lower()
        why = _hallows_reason(title_text, body_text)
        if why:
            return True, f"{why} | read: {(title_text + ' / ' + body_text).strip()[:160]!r}"
    return False, ""


SLOT_SCANCODES = {1: 0x02, 2: 0x03, 3: 0x04, 4: 0x05, 5: 0x06,
                  6: 0x07, 7: 0x08, 8: 0x09, 9: 0x0A, 10: 0x0B}   # keys 1-9 and 0


def slot_region(n):
    left = int(round(HOTBAR_SLOT2_LEFT + (n - 2) * HOTBAR_PITCH))
    return (left, HOTBAR_TOP, left + SLOT_WIDTH, HOTBAR_BOTTOM)


def slot_key_name(n):
    return str(n % 10)


def is_held_blue(px):
    """The bright blue outline a held item gets (no red in it, so purple/cyan rarity borders don't count)."""
    r, g, b = px
    return r < 60 and 125 <= g <= 215 and b >= 215


def slot_outlined_blue(n=None, save_debug=False):
    n = FIRST_SLOT if n is None else n
    img = grab(slot_region(n))
    if save_debug:
        img.save(f"debug_slot{n}_crop.png")
    w, h = img.size
    px = img.load()
    t = BORDER_THICKNESS
    total = blue = 0
    for x in range(w):
        for y in range(h):
            if x < t or y < t or x >= w - t or y >= h - t:
                total += 1
                if is_held_blue(px[x, y]):
                    blue += 1
    frac = blue / total if total else 0
    return frac >= BLUE_FRACTION, frac


def slot_is_potion(n):
    """True if the label above hotbar slot n says 'Potion'."""
    l, _, _, _ = slot_region(n)
    img = grab((l - 8, 918, l + 89, 960))
    big = img.resize((img.width * 4, img.height * 4), Image.LANCZOS)
    arr = np.array(big.convert("RGB")).astype(int)
    mask = arr.min(axis=2) > 190                     # label text is white
    v = Image.fromarray(np.where(mask, 0, 255).astype("uint8"))
    text = pytesseract.image_to_string(v, config="--psm 6").lower()
    return _has_word(text, ["potion"], cutoff=0.8, minlen=5)


def _fuzzy_in(text, word, cutoff=0.78):
    """Loose match of `word` inside OCR text; tolerates a wrong or extra leading/trailing letter."""
    L = len(word)
    for tok in re.findall(r"[a-z]+", text.lower()):
        if len(tok) < 4:
            continue
        for ln in (L - 1, L, L + 1):
            for i in range(0, max(1, len(tok) - ln + 1)):
                if difflib.SequenceMatcher(None, tok[i:i + ln], word).ratio() >= cutoff:
                    return True
    return False


def _iter_label_texts(n):
    """Yield OCR readings of the label above hotbar slot n, one reading method at a time.
    1) Black-outline reading: every mutation label has a pure-black outline, so reading only
       the black pixels works over bright backgrounds (grass, sky) where color reading fails.
    2) Color/brightness reading: works over dark backgrounds (night events), where the
       black outline blends in."""
    l, _, _, _ = slot_region(n)
    img = grab((l - 8, LABEL_ROWS[0], l + 89, LABEL_ROWS[1]))
    arr = np.array(img.convert("RGB")).astype(int)
    sc = HOTBAR_LABEL_SCALE
    m = (arr.max(axis=2) < LABEL_DARK).astype(np.uint8)
    big = cv2.resize(m, None, fx=sc, fy=sc, interpolation=cv2.INTER_NEAREST)
    k = np.ones((3, 3), np.uint8)
    for v in (255 - big * 255,
              255 - cv2.dilate(big, k, iterations=1) * 255,
              255 - cv2.morphologyEx(big, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)) * 255):
        yield pytesseract.image_to_string(Image.fromarray(v.astype("uint8")), config="--psm 7").lower().strip()
    pil = img.resize((img.width * sc, img.height * sc), Image.LANCZOS)
    a2 = np.array(pil.convert("RGB")).astype(int)
    mx, mn = a2.max(axis=2), a2.min(axis=2)
    gray = pil.convert("L")
    for v in (Image.fromarray(np.where(mx > 150, 0, 255).astype("uint8")),
              Image.fromarray(np.where((mx - mn) > 90, 0, 255).astype("uint8")),
              gray, ImageOps.invert(gray)):
        yield pytesseract.image_to_string(v, config="--psm 7").lower().strip()


def slot_label_texts(n):
    return list(_iter_label_texts(n))


def slot_label_has(n, word=None):
    """Does the label printed above hotbar slot n contain the mutation word (e.g. [Dracula])?"""
    word = (word or MUTATION_WORD).lower()
    for t in _iter_label_texts(n):
        if _fuzzy_in(t, word):
            return True
    return False


def mutation_seen(n):
    """Mutation check for the character in hotbar slot n: hotbar label first, then the in-world label."""
    if slot_label_has(n):
        return True
    if USE_WORLD_LABEL:
        return held_mutation_present()[0]
    return False


def _mutation_tokens():
    img = grab(MUTATION_REGION)
    scale = 2
    big = img.resize((img.width * scale, img.height * scale), Image.LANCZOS)
    gray = big.convert("L")
    arr = np.array(big.convert("RGB")).astype(int)
    mx, mn = arr.max(axis=2), arr.min(axis=2)
    # Mutation labels are colored text (dark red for Dracula, etc.), which plain grayscale
    # turns into low contrast. These variants pick the colored/bright pixels out instead.
    variants = [
        gray,
        ImageOps.invert(gray),
        Image.fromarray(np.where(mx > 150, 0, 255).astype("uint8")),            # bright pixels, any color
        Image.fromarray(np.where((mx - mn) > 90, 0, 255).astype("uint8")),      # saturated (colored) pixels
    ]
    l0, t0 = MUTATION_REGION[0], MUTATION_REGION[1]
    toks = []
    for v in variants:
        d = pytesseract.image_to_data(v, config="--psm 11", output_type=pytesseract.Output.DICT)
        for i, txt in enumerate(d["text"]):
            if txt.strip() and float(d["conf"][i]) >= 0:
                toks.append((txt.strip(), l0 + d["left"][i] / scale, t0 + d["top"][i] / scale,
                             d["width"][i] / scale, d["height"][i] / scale))
    return toks, img


def held_mutation_present(word=None, save_debug=False):
    """Is the mutation word showing in the label around the held character?
    Matches that sit in a 'Caught ... [Mutation]!' / 'Got ...' catch message are ignored."""
    word = (word or MUTATION_WORD).lower()
    toks, img = _mutation_tokens()
    clean = lambda t: re.sub(r"[^a-z0-9]", "", t.lower())
    feed = [t for t in toks if difflib.SequenceMatcher(None, clean(t[0]), "caught").ratio() >= 0.8
            or clean(t[0]) == "got"]
    hits = []
    for t in toks:
        c = clean(t[0])
        if len(c) >= 4 and difflib.SequenceMatcher(None, c, word).ratio() >= 0.78:
            in_feed = any(abs((f[2] + f[4] / 2) - (t[2] + t[4] / 2)) < 14 and 0 < t[1] - f[1] < 450
                          for f in feed)
            hits.append((t, in_feed))
    if save_debug:
        from PIL import ImageDraw
        d = ImageDraw.Draw(img)
        for t, in_feed in hits:
            x, y, w, h = t[1] - MUTATION_REGION[0], t[2] - MUTATION_REGION[1], t[3], t[4]
            d.rectangle((x, y, x + w, y + h), outline=(255, 0, 0) if in_feed else (0, 255, 0), width=3)
        img.save("debug_mutation_crop.png")
    return any(not in_feed for _, in_feed in hits), hits


def _sample_basic():
    ev, text = event_active(save_debug=True)
    eq, frac = slot_outlined_blue(save_debug=True)
    print(f"OCR text in event region : {text!r}")
    print(f"Event detected           : {ev}")
    print(f"Blue border fraction     : {frac:.2f} (needs >= {BLUE_FRACTION})")
    print(f"Ada looks equipped       : {eq}")
    print("Saved debug_event_*.png, debug_title_*.png and debug_slot_crop.png - open them to "
          "confirm the regions line up.")


def focus_roblox():
    """Make sure Roblox is the active window without resizing or minimizing it.
    Returns True if the window was found."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, "Roblox")
        if not hwnd:
            return False
        if user32.GetForegroundWindow() == hwnd:
            return True                      # already in front: leave it alone
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)       # only un-minimize if minimized
        # tapping Alt lets SetForegroundWindow succeed more reliably
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        user32.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def _send_scancode(scan, hold=0.15):
    """Send a key as a hardware scan code (what games usually listen for)."""
    import ctypes
    from ctypes import wintypes

    PUL = ctypes.POINTER(ctypes.c_ulong)

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", PUL)]

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                    ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", PUL)]

    class _I(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("ii", _I)]

    def send(flags):
        extra = ctypes.c_ulong(0)
        ii = _I()
        ii.ki = KEYBDINPUT(0, scan, flags, 0, ctypes.pointer(extra))
        x = INPUT(1, ii)
        ctypes.windll.user32.SendInput(1, ctypes.byref(x), ctypes.sizeof(x))

    send(0x0008)             # KEYEVENTF_SCANCODE (key down)
    time.sleep(hold)
    send(0x0008 | 0x0002)    # scancode + key up



def _rel_move(dx, dy):
    """Real relative mouse-move event (SendInput-style). Roblox menus need these to
    notice the cursor is over a button; a plain jump of the cursor isn't enough."""
    try:
        import ctypes
        ctypes.windll.user32.mouse_event(0x0001, dx, dy, 0, 0)   # MOUSEEVENTF_MOVE
    except Exception:
        pass


def _hover(x, y):
    """Move to (x, y) and wiggle a few pixels so Roblox registers the hover."""
    pyautogui.moveTo(x, y, duration=0.15)
    time.sleep(0.05)
    _rel_move(4, 0)
    time.sleep(0.04)
    _rel_move(-4, 0)
    time.sleep(0.12)


def _click():
    """Click with a short hold; instant clicks are sometimes ignored."""
    pyautogui.mouseDown()
    time.sleep(0.06)
    pyautogui.mouseUp()



def _scroll(total, chunk=100):
    """Scroll the wheel `total` clicks (negative = down) in chunks, so the game sees
    every bit of it instead of one giant event."""
    sign = 1 if total > 0 else -1
    left = abs(total)
    while left > 0:
        n = min(chunk, left)
        pyautogui.scroll(sign * n)
        left -= n
        time.sleep(0.03)


def sample():
    _sample_basic()
    print("\nHotbar overview (slot, held?, potion?):")
    for n in range(1, 11):
        eq, frac = slot_outlined_blue(n)
        print(f"  slot {n:2d}  held={eq!s:5}  potion={slot_is_potion(n)}")
    print("The script starts on slot", FIRST_SLOT, "and moves right until it finds a potion slot.")


def mutation_sample(word=None):
    """Shows what the script reads: the label above every hotbar slot, and around your character."""
    from PIL import ImageDraw
    word = (word or MUTATION_WORD).lower()
    print(f"Looking for        : {word!r}\n")
    print("Hotbar labels (what it reads above each slot):")
    cells = []
    for n in range(1, 11):
        texts = slot_label_texts(n)
        hit = any(_fuzzy_in(t, word) for t in texts)
        shown = next((t for t in texts if t), "")
        print(f"  slot {n:2d}: {'MATCH' if hit else '     '}  read={shown!r}")
        l, _, _, _ = slot_region(n)
        crop = grab((l - 8, 918, l + 89, 960)).resize((97 * 3, 42 * 3), Image.NEAREST)
        d = ImageDraw.Draw(crop)
        d.rectangle((0, 0, crop.width - 1, crop.height - 1), outline=(0, 255, 0) if hit else (255, 0, 0), width=3)
        d.text((6, 4), str(n), fill=(255, 255, 255))
        cells.append(crop)
    strip = Image.new("RGB", (cells[0].width * 5, cells[0].height * 2))
    for i, c in enumerate(cells):
        strip.paste(c, ((i % 5) * c.width, (i // 5) * c.height))
    strip.save("debug_hotbar_labels.png")
    print("\nSaved debug_hotbar_labels.png: the label area above all 10 hotbar slots "
          "(green frame = match, red = no match). The text label should sit in the middle of each cell.")

    present, hits = held_mutation_present(word, save_debug=True)
    print(f"\nLabel around your character : {present}")
    for t, in_feed in hits:
        print(f"  match {t[0]!r} at ({int(t[1])},{int(t[2])})  {'(ignored: part of a Caught/Got message)' if in_feed else ''}")
    print("Saved debug_mutation_crop.png (the area around your character, as before).")


def _click_slot(n=None):
    n = FIRST_SLOT if n is None else n
    l, t, r, b = slot_region(n)
    cx, cy = (l + r) // 2, (t + b) // 2
    old = pyautogui.position()
    _hover(cx, cy)
    _click()
    pyautogui.moveTo(old.x, old.y, duration=0.15)


def press_slot(n=None):
    with my_turn("pressing a hotbar key"):
        _press_slot(n)


def _press_slot(n=None):
    found = focus_roblox() if AUTO_FOCUS else True
    if not found:
        print("  (couldn't find a window titled 'Roblox' - click the game manually)")
    time.sleep(0.4)
    n = FIRST_SLOT if n is None else n
    before, _ = slot_outlined_blue(n)

    # attempt 1: hardware-style key press
    try:
        _send_scancode(SLOT_SCANCODES[n])
    except Exception as e:
        print(f"  scancode send failed ({e}), using pyautogui key")
        pyautogui.keyDown(slot_key_name(n)); time.sleep(0.15); pyautogui.keyUp(slot_key_name(n))
    time.sleep(1.0)
    after, frac = slot_outlined_blue(n)
    print(f"  after key press: equipped={after} (blue={frac:.2f})")
    if after != before:
        return

    # attempt 2: click the slot on the hotbar
    print("  key press didn't change anything, clicking the slot instead")
    _click_slot(n)
    time.sleep(1.0)
    after, frac = slot_outlined_blue(n)
    print(f"  after click: equipped={after} (blue={frac:.2f})")


# ======================= SELENE'S STORE =======================
_TPL_B64 = {
    "cash": (
        "iVBORw0KGgoAAAANSUhEUgAAACYAAAAeCAIAAADPdvs5AAAIjklEQVR42pVWa49dVRl+3rXWvp3rnDPTdnqhl5SWGksLLRhKCEoj"
        "AdQEUBtIvER/gN9N/OaP8DvEaFQSxUQ7MSChFASU0tLamQ4w7fTK6Zw5M+e6L2ut9/XDacd2Kh98srP3/rSe9bzv816oMUPamyAL"
        "onIETbGKrXNdu+pgSUhbE0qoE0NEZV3uZt2UU5PG4eIG+07DXdPhFpQfKeLtfiW+noZ9r5xirZ0OwpAUBcoo1qt21YkDoLzWXhsA"
        "EHhmL55ZFJQIQCAhAgHw7CGAV+yUckE8jPD+xv5bJd/V0UY1OM+9f0bJdhU/sjV+sG1rQ9FW4FlYREhI406IsOjkh6RZISOlNQBi"
        "YmGLQiAEIlbIVIA4WK3SbBPdMP39hv7bcVjT08eiTcei2gGjIxp+yoOPTPFRNezUw1qIwAFEJCICgZWCIQBIlFih5oxSrKmvIIAC"
        "KaKQnLYsDEA7E7Qq6vSWzmuJXQUAHdPUN4MNzwV+g24PVBzIZFko4+6HbvmEG8x5cRzvQOXo0O+/6UojCdgpd+s01siImjMKQlqU"
        "jG8CEYiQQKBtFM9Pj/7clEvJnm07Xnrp2fc/Pn1574V812gV1BqqwoEIRqORyEQgMbO7zp13Xe+ssytsaig/lqtHO9nGZRtkAEhI"
        "iRpTjuN86wsBhJLWlH9jU3YqmlbVF48+8PK3d22rLvVs3Kolv2ud//ty+2LmRpZYoAiVGEbDKKkoSZyoHg/m/Op7rlhxKpFwhzeH"
        "+27XclbugoQaM0RCa5TEOhgl5pPN2Tvl+Ao9fp879qR57MHq1klWvgcVFSq8Vvi5LP2X0//g5JIEjig0ACGz1E/hPCoRysK6w/ki"
        "98+60aIX4eh+Z57oDHZdvqUyQKBYg8gMS/74luEbwb6Kf+7h4sUj2Z4tPgkFAAhrb0+0SuoCRR9SaRbRIodDUQNLVzrUGZBRKEWo"
        "JVILxHR59KnrfOAGc7Z8wPFP/20AKFHaBeWopCmIehs/f80cnHa/ODZ8fL+tV/i/TCSg8Q+0kkniI3CHaDSP6G1XOevjSz5Y1qar"
        "yHr0RsgtqToakwhiQi6yANtSIWszzipbtoH1haY2BSzfP2wP73DlsiAUGECNxQnuBgEx5ICk+8NsgcOTunKcK6c4vDZUomjzhNQj"
        "7rVt62o+antDCgB7GbcCEg/KQj41deVVowI50yxVxTx9bTBdckFTqCyA3JK7ZjEQeOw1KMb9sPfzyrNB/3i58mvUuvVARK4tpJ0l"
        "awu+ZRdAWKg5o7TT8Web3Fubuu9p01CbXwinHjcrKaHvf2D636P+HpOrGhCv+fn2cw9YYIX6oj52yU/Oxa2+eC8AqEXmpIonmH72"
        "idFFFJ26b/Cnmu2o2kGz8flQNqgLq6qXUjOh47XarEm+lqVPrw72+lyVBTGg8WVQQCQSpP7wSuqHgfe0PheaTPjejt7rVaX0xm8F"
        "lUMmq6nWgAY5eUYnpYtGF3VaLutzYbw/z76RDXeneRIxJQRzT3ZNCZbQHdFIYstgAdZRisRshm+X8oGqfydMjpigQVlORKQUmFE4"
        "jAoUTKtG9yJ9MQhmw+hwlh4u0p3O16sNamxHXIbrggziLcgLXD2LwQj+S8PAYMMD4kT1GsZ71UgRB7K1gX6GXorMklaUOzGaAAy8"
        "/oKS03F0Mig9McoPdIOdOpqqHaTJTahsw6iL2T9itQ9/T5ItMCRYUACADEAQ5A7ZgLopSiFNVWWyIhMlDHN0U2oPKLWwDoMMXkgT"
        "XQyTdyjeWtiXl2afu3n+vsmH9cEf4ZPf4sZH8PndgQRyUEvp8xRoivfZAuN5eRvOo5ein1Ec0FRFJqsyUZJhTu0BdVN4DxYA1M8Q"
        "h8S18JWoNtNOXzl9oh5upJVL9/AR5UTnlZqjUKP6VOaPXh6PaFlnAhGkBa6uUKtHzQqmq3rfJuoX9mYPywNyHs2KbK6LZr+4mC9c"
        "L/JAZGWBisF693ZJnVR0mcq7JXm+M9p3BRDt7la5jtg6LPXQG8l0pby7Wd9zn+oVg0HhJ8Iw6/v5z1tL7bzuRQfA8hzU6K5i8FB/"
        "U6aPqWfAR6+PJpZZO+WVMJt7fHxXIjwjtXK1O1xJi4k42tNs7ozjy9eX5hdvrPZH3gkIGqB8gJjXTkotnfgszFeo+lUKjy53mx2v"
        "CgAgGjc8Af53K7ktVwrvi9T3sryX2bpXy9fbg+HIM6912vFcB4EFrb5+/Wz06gexa6L89d6g1nba3jqfRAXK6AZTh2neQQFNJQl9"
        "mWwvspyOlnsZ0hFu892JzNFCW//hdPybM3GrgfLTg+IrN4pwKOC1okQIU3pyKEOdfZy5z7XsD3mXRk1JiaDwf6GXq9mb+lfvlmYW"
        "Q7udSy+0h9tvsHbr4sdgHf68W96DEIFcJlzwNO+QAzUFAsZr5TrRuUNux+UCQezwY3as5cSl8JdvlN/6IjSPWP3ylXR6CUoIROvn"
        "3e11K+Yo7kz6DydXjgejK0Ci5KGAHw1ls0awTk6G7giOASBDsqCOLdlyiL/MB0sxTXx3mB+5JIE3YsZ3ZfYWlmW8VJJBQM0ZpbwO"
        "bViJqpqiKK+kp6PWX2k4rwUku40cCni3QYnuorRMbVKnlLpEMQuA8EFEL7bznS2nnGEdB7ExxijDjju248UDUKyNN2Yslh1ncSoq"
        "daUMh0x5b16+VinebAxnpXjd0ZSWhwPZa6SuACAjtaDoNAWOJp7i0rO90CaD+s1RadWZXLEWFivWsTNi9B2jjgDh8VYAGYNFPHkJ"
        "fFHrSdIPNvenrjTcmerwXDB808sZLbsNmow5Uoso1an+TEYPdbL6UFGpsD2P4nbyBQALCwkL0x2VvkYJX7AdOtKUq4I0CcEby/VV"
        "H41UPWkcmKrOlUfnguG/nFdkBJUHOHmyX2xb4jinnEaamfyaOdmJ804ZsmSVUneahx3/B/Ew9Oltbbq8AAAAAElFTkSuQmCC"
    ),
    "gem": (
        "iVBORw0KGgoAAAANSUhEUgAAAB8AAAAYCAIAAACNybHWAAAHGElEQVR42mWWaYzdVRnGn/ec89/uvf+7zNbO0k47TNpOpdJCwmIM"
        "QqCVCAQXEGgbUtE0EELUgiYkJkZjoib1g180YIwaQgUU0xjFRlm0rC3QTbtAp1SmM9OZuTP3zv3f7b+cc14/tAkaf9+e5M2TPM+X"
        "5yVx0OK/EI2aem6vOnuqf+OWoU8M54quQwRHJSADsswGFBvOUm2tIQvqJI3Ji0snj+nxK7Mv7bGFysdeDEXMdFlYtJbVcz/xpt/P"
        "f+YBHU7kh71P3VAqFuSspTpTy6Bh0DSAgbSsmMuxzs5GWTnL+jZGrz3Dv9tr7t7D+QqIQABIBru+45F1WXuNedr/pH/uSPnmXcnQ"
        "zbYwaLXyyBnoLzRlELEXWa/LrmFXkOuTW0mlmDEdU6iLFRENe2HeHv2zWJxxV69Xvu8QSbbS2/544Ai/VRMvP89v7F9558PtwVu1"
        "0yNc6YaqXUvLMYcsbJtF0zpN40U619SF5bR8pjZTF91ccX7JaSU5kx8KK0H6ytOSjb9q3Mnli66S8t491G3Hr76QvvibtTu+Ho3d"
        "lYoiGK6DFSuoryw2+7imT/oBSQ+xorqg2CEtaaLbPX5BzDeCdiSMgZU5E15R6vdbf/mFFcoOjZOXU6Lbsm+/yH96at2OR5pbdpoO"
        "2RRpF70l9FdYXjCfvD3oSDQ0TseYypAxiFEC0uHh8vEPGrm87ArdYi6IJFeI1nyt8tmk/uLPSCnc9oB0x6+Uf3tm3bY7ws89tNjy"
        "2ovIuigWMTqGXtde5aG4Si4zDrRxQUMzCJAMk+F0hzZzspCoLOeaLvQyUwrhiOL4RIB6580/cr6kSKg4ap1//dxw7/GRsTVJMYwp"
        "PzAqc4G1VX3DJqcCvEMY9lDrosOQgMtY6iIxmF7dIycvBiXHGwvMQuzKJtIoOVVrnZ7PGhF1miqbuJbXbYnePYxjJ8rhWjNXq4SL"
        "/X5gHadHu72B205BAmMKiYMlDckgDWHZGnYcNVrQM8sfJZobM2mz61qpsurpZOqQXL/BbLhe6cExtW07Lkw2j+yXG2+IW0PLU3H0"
        "wVJY0JgoH7wYRECbkBEci4plF9ApdNvqjLPY1ucatROzzbTYNn3WDVRhyfzzBSoq2rpDj6yT8qvfk2FFFor67T/wUj285rpWLVyq"
        "5avVtBlXk839hzJ5sonjNT5b46WIdcr1lGdbyFica9oLr/1reSbo0mr2C06+Y8/8khcPOnc+iOtvR74iXJMFYZi//tb8tns6x5/P"
        "jv0+7I9UIKwTJiYftup9o45Y6bjDri14UeY3HR89/oMb/R+s97yP6smcNhyQEtJpUvWv5v197tU3Brd8Oejpzwsj3fsfd1xX5Aq5"
        "8U3m/InW4QOFsbWiZ1WqfKNgqxdHrhuZbSK6iNp5NOpoJCjlMKzw20P48NBbcdUBAhloqY9l7+yVQwP+oz+llWuklHkphDE6Y4oh"
        "01J/8PAPxeBA/aWfe/pwYcQmQTC1qORktXXe1iaRNsGMDKjV8co5PjbdaL8/y1aIvBD6jD7+JJVctftHpnc4hUqZMoaU9z0mHZeI"
        "iMD5sh0Y1adeN9OTuVUjGFqTFUIxe6FhB9otwRbCB1y0I7v47nLy4bFskSkoS0zbyX0kq+q+x7D5JihHSEXMAizlvd80SdcksU5T"
        "Ix0zsJqCnDn1BlenS+vH/ZHBzvR8sTdstBwrhQwAjWw6TY9c5KmjCFZLN+LzL8BMylu+aG/ZTo5n4o7NUqtTY0nKh37MXsBewI6v"
        "pbLK5ZWjQnfNib/Twtzg5g3uij6an+ugwp4ihlmwPNXGubNsUlHwMbWfm++Ka2+0dz3ClUGWDrkeHI+VZ4QjtJBGOkY6RiomAcDm"
        "S2brTtz8+fbZfyzse6qvj0xUG+yNfbJ6DnbaYLaO9oeidwxzL9mFV2nTFr5jt+1fxYAlMkIZoYyQTCTpK9/F/0IAvByGrqAs7rz8"
        "tJ6JVn36al2tR7Nht6q4mVBtTqTTIjltP/iV2LCe7v2WuWIziPB/KIeNwOV50iANCQBEXB5Qt+20cWvuwLNSsiytKQxWYicXd5ep"
        "9p7kf+szz8rREWf7t5O1m4iIAQIEs4QFQCBmKJUlec+VUiriRNu6sYYEAUSQ5b78F3bHWTz/1gG3sj53ZSnXH+jOtF08aDpHZF9Q"
        "3PWEP3FVTTrppdDMwmaeIOUoASiw4izJPC8F+SAIFgYGYGZpjIVIV6yRdz+KuN0+/GZ2VPgTrliYM9EREab+/U+YTTdyLhSpATOI"
        "CAyjjXCYhSAoYsXWWgYzafClrb1cPdiytdLlkXXB9sez7vfjkyez937NnFGYuXfs4pvuyRzfXLqlj/8AZhgGAwaQ8p5vEIGtYaMt"
        "kEFYIiISRnOnKaSENRz2iNGNdu6sqZ5EYJyt99lbdwo/z1azNZqEgbjUDOmUdUYEGA3L/wF4RNJAUAG9vwAAAABJRU5ErkJggg=="
    ),
    "robux": (
        "iVBORw0KGgoAAAANSUhEUgAAABQAAAASCAIAAADUsmlHAAACZ0lEQVR42o1SXUhTcRQ/98Ms5I7wqw0Gfaygm5Y+mmB7iEKIHopC"
        "CslKqLeIKMJpulwb20u0lYERhUVi9FBQWH5UmFjZg1pmTNPUvJofc8y5rnf34396GN1WqfP39P+f3/n9zuGcA2mXuPVVxoauekII"
        "IiKiqqm339XmuHlXs6N/yt878bHs6QWrL//VwEv8jQVZtDdWgKki9cNopx5tH2qz+vJPNZwQQmO6HSGkf8pfdPfgsftHRmaH9SBU"
        "NZbHPkExWFpfsvtGwfvht7osHoSQZv+LXd6drmaHrMqICF8m+2Kt7qmxlj+7qGoqLouoIpXWl5x/chYRIapIiNgtdOW4eUVTcAWY"
        "W5jb6tyEiPQqNhkARPlnlimbpVlYAQyrDUbOBAB/sv9RzkSmczx87E1TjFA9Hc+yNPOX+H8omkIMQKmQJOGiCQn6xCRqGTaBmJlF"
        "AAA6kZggiSfSUtL7yr4uZaohAQBWIxpDMyzNDkz3x9M0RWdy6xZVRlVpfE4AAHoiPAEAWabtISlU0+5LuCdEdDTZs4zZAAC1HTdj"
        "q+8RunM9/NG6w0OBwaXO49N4z/5bhftq9wqhMUQE3mmZCk/GOFEW3S1Oy2WzvbEiLIXjZYHIzLnHZ3I9/KPuh/rlQ3oZV+DN06sR"
        "Qr4HR48/KN7m2lzXeWdemg+KwetvrvFOy5UmeyQa0e1a/E2Q0pqabuPMlZmeVpcoi7pF2+DrAm9ehs2QYTMU3yv6FhjSC46HhNMN"
        "JzNsBooVM9kRsua5zATQvNZcWVh9YMchfXmff/RyydyG1I0URcXmXNPu87ZdFWVR2cL8Ar1P/PNhmfWsAAAAAElFTkSuQmCC"
    ),
    "close": (
        "iVBORw0KGgoAAAANSUhEUgAAADEAAAAxCAIAAAD8/tZLAAAHQklEQVR42s1ZXUwbVxa+d+6M8eA/cMA2Dj8ODZBNoEkg/ylN0qRE"
        "UbVqK3V325egtFUjRf3Z14o+9KEPqz5sV63aqFGrtH1I2+RhqyorrbRKIkjYwHZJCEkTaogDARtj/tb2zHjGM/fefTC2x2AbQ8jP"
        "0ZEYhjv3fuc7555z7gXuB0+cME8eJMAmflw6fvyxQznw5ZcZmCjGC4dA+Jh5IoQAAJZA8ahQzmMChAAA6CpO/AAGZPC0NFWPBGUG"
        "T6tM1YPypIvxxx5VyX2X5CkrVfDRejN3LtAJXTgVfNQ8ZTcpN8RVZ6sgnrI79KGxlRMToXRKEM7fukUBgABACBkIIYSJ59SDkeN2"
        "r1tXYbVCAFSMbweDd6ens4xPvkEMU1lSssHpXAkmAEAxQjaj8brfn+97hsEY/37TJg6hiXD4ktcbEoQ8AWA1Gl1mc363ZMOUdArP"
        "sruqq/3h8JymNTz/fOvbb1NCEkowpoRIc3Odn3wy5PX+9/79Jpfris/3P4yffvnljUeOkMRIjAkhRFWDd+70nj5tYJitbned3Z6/"
        "vObjCQJQZjQ+6/Gc93qnfT62qGj9vn36AXFJghD+/b33ekZH783MjEQizsbGwx98UNncnA5ESiOBwPmODpZhau32FrcbJdNhrohE"
        "HgAAAH+qqQGULlYIgIll45o2PD4uhEL1Bw8WmUzpj1nW6nJJ4bD36tVpSSouL2/r6Nhw+LB+MSUa7f3mm6unTtkROuDxOE2m1OQp"
        "1hP648hIJqaqqqyYAKUshBaDYSISCfj9lJC6/fvTS0LI8bzN7Q4MDMTC4ZbXXnvmxAmO51OANFn2Xrz4r48+orOze6uq6u12mGMV"
        "QOmPo6MZmP64di0gJKtCSo0MY+K4oamp2UDAXlPjaGhI+5dh+JISi8OhStKh998vqaxM71yMJ3/77Z8ffhi6cWOzw7Hd6WQThTWH"
        "nh0by4wnTcuzERAAVcXF28rKuu/d6/rss4rGxjW1tam/cjy/oa1tTW2tHisAQAiFrnzxxWh3d43F0lJWZqA0+yqLomqepz84nXks"
        "AISwlJpYdi4WGwsENEWpO3CAYdlU8mSLiqwVFfowioXD177/vvvkSYumtbpcbp7PmFDvteTLcxMTmTyp6pJlvxShbXb7dDB46+ef"
        "K7du3dHenmukKsujvb1XTp4E4XCzw1HN8/n9oJe/tBbmu9QRx81xLVZrl9/f8/XXazdvXrtlS5YqRMiMz9f16adhr3eT1fo7k4nR"
        "tMJLJMskz1JEVQtRjpD1PF9rMIz391/+/HMlGl08qTA93XfmjPfCBTNCzRYLTwhV1UJ03nKU6ukKr+IAMADgeDwaCkGGyRayEDKM"
        "Fo9DlkUQErq8NoLSFE+UFqIyxiOSdF+W7R7P7jff1KeilPAlJRuPHKndu1fEeCASUQjBlBaiic8xTmJa8gNCqUbIpKL0hcNMWdmO"
        "9vb6557LyhPiuIqmpj3HjxtcrkFBGBbFAg2eT7O4YJ4wpXOqei0SiRqN9YcO7WhvN+iKzAIpMpvrDx7cfvSohNDNaDSkKIVjIoVj"
        "EjVtUBTvq2pFU9O+d9+1ud0L9pqmKPo35vLy5ldfXd/WFlSUm9GohHF+J6QwpeMp/+g4IWOy/KsgmKurnzlxYkEKiIvi0KVL//n2"
        "W30DzSBUXle3+403bA0NvljMK4p4gZ0ApBQDkGpLGLgUT5hSjdLpePxGNEpLS7e88sqmF15AHKdnKOT1Xvj441+++87X3a3HyvH8"
        "uj17dh47ppnNg6IYUBQ9jly+Y5gCfBdR1V8FYQ6hp1pb97z1ltFm0y8cmZi49sMPdy9f9g8M9J4+LYRCGZ3qmjVPv/RS44svzmJ8"
        "WxAiqooJSWu2fcegpXwnYeyLxe4pimPjxmffecfu8Szw2nBXV9+ZM0CWWUkaunjx+tmzGcdXCO01NduPHq3Ytm1clockKU5I2uBM"
        "Kch3KiFBRbkjiqaqqp2vv16za5e+ylJKJwcHe776SgkE6ouLN5hMcjB4/dy5kZ6ejNRgMFS1tOw8dox1OIYlaVyW8+endA3G2bLt"
        "rKreFsWIphmmpv596tTNn35iEIIMk1AAoTQz4+/rcxoMDcXFAICIpo319/+jo8PR0JAaxiAEIYwEg1jTRE3zSpIZIVuyp8h6aMvA"
        "pG8JYoSMyvJkPE4BUATB39+fvVlg2VqLxYQQobS6qGhWEIY7O4c7O3MtORmP343FGk0mlKQcLqpdbMp3iw80HqPRwXE0CZ8CQClN"
        "PyfSI4SlHJcwqZTjtpjNAsY06dzUMJr8FQBgRohQmqslYpgUT9nO5jyEfCbJMEfZTJjEAlDOsuW5/JLZmeFctRnm5mn1JXMJmPv2"
        "IB9PK7qPgA88Q959t5L7pwfmm1LAAgA6bDaySjyt2r0KfsiAlnUZOe87vNTl03IvNuEq8LQyTA/tiowFAPw1sx1bsfx5cfpbPs2E"
        "AHYV4+Zvi6dfvsTjT97/ymQF/B8mjSORD05f1wAAAABJRU5ErkJggg=="
    ),
}
_TPL_B64.update({
    "rebirth_btn": (
        "iVBORw0KGgoAAAANSUhEUgAAAVkAAAA8CAIAAABD3l7RAAAgAElEQVR4Ae3BCXgT1cI38P85k8k2SQsUEWQTN4ooEiWCC+OuKF5w"
        "GxVBkWJGXBF3ceFiXNApo7hcRMV6ERQXqoIbKipXqiDaK7veqSJLhQakbdImTTJzztdvfPo9jCkCyvve74n9/Qiq/GjTps1fHsEP"
        "Etq0afOXR/CDhDZt2vzlEfwYQJs2bf7yCNYH0aZNm788gvVBtGnTQvgFwiZOEwAD98HqArMrAUWbvEfwUwHatAGEn7lvMReqOZxY"
        "AOmBNBMiaJPXCH4qQJv/v5EMxNVc2MbB8FsErJBkiwlrjz/D/S33fcLAsCvmQaRxOIWA/y6SgbiaC9s4GH6LgBWSbDFh7dHmDyDY"
        "UIg2/x8jjQjMNmkcv4O7kDxfMA8k+EPE/3D/2xZaFPoK+3Y9QhTE9dvWb9yxAS2yfUjyXAH/PaQRgdkmjeN3cBeS5wvmgQRt9hLB"
        "xkLkPQvCNk4asacIIIKLYAHCA/jv8n3A3CsZdoe1IwlVwN4jWQSfM0kDmvnc/ocvmDLquCtc1AXb8p++uvHl69dtWQtb4yWC2ZPg"
        "v8T3AXOvZNgd1o4kVAF/FGmEsI3DQuvcsPYn3I38Q7CxHfKasIX751u0nuMP4SJYR2L2IOaB1OxBQPC/LPCCKWznAPp1O6pXx15w"
        "akg3LFr3MWzx60QuYW+5VzPfexZsr45746y+Q+BUl6wb/Mjxm3ZsBJA9jCbPE/BfEnjBFLZzAP26HdWrYy84NaQbFq37GLb4dSKX"
        "8Ad4P7E8XzP8Lu5C0+lCph9FfiHY2A75i5gIPGfSBMe+wIIk049mBlDuwf+a4DMmjXMAmqJHZBVORswIR0OwJSIu1p5gL/nftcQ1"
        "DMCJhw5+58b30Zrpnz59V/kdALgP8RtE/DlCDXd/w4RfODh+i4C1J+kQtboS5Ag+Y9I4B6ApekRW4WTEjHA0BFsi4mLtCfaSewXz"
        "LbSwJwgaLndZnQnyCMGmdshfrk1cetnEPsW9aJKFTIjif0VwuknjHICm6BFZhZMRM8LREGwJ1cXaE+wl6RXTtZEDuPG0m+4/7wG0"
        "ZvH3nw1/6lzY6m8TQfGHuTZz6RUTDL+HIHmBkD2Ewik43aRxDkBT9IiswsmIGeFoCLaE6mLtCfaS9Krp+oljz6SPo02ygDxCsLk9"
        "8pe4jvnfNgFIHqm6tAZ7LGNl6pJ11bWbv9/6feWGrz9e99GP237ETsyDafJvLu7F/7Tg9Cyt5wA0RY/IKpyMmBGOhmBLXC2y9gR7"
        "SXrVdK1nAK4+adwjF5WiNe+smD/q+cvQTED9bW78CdKcrGsTx+5YHUnDVSKcgtOztJ4D0BQ9IqtwMmJGOBqCLXG1yNoT7KVAWVao"
        "4QDuPHvinedMRGsufubCD9csBJDpT1NDXMgjBJvbI3+J65j/bROA5JGqS2vwJyz/6atnPvvHm5XljDPYrP1J46Ui9+F/VHB6ltZz"
        "AJqiR2QVTkbMCEdDsCWuFll7gr3k+9B0VzIAh3Q65Kt7KimhyHH9nGtnL50FwOpEGkpE/AkFj2VIGs3OP/qC3p2L4bTxl40vL5uN"
        "ZgT1t7ohYGfB6VlazwFoih6RVTgZMSMcDcGWuFpk7Qn2kvSK6drAAIw76ZopF2lozVn6acvWLwOQHiQ0nSwgjxBUd0D+Etcy/9tZ"
        "AJJHqi6twZ9WueGba2df/d3W72CzDiANo9wQ8D8n+I8MrecANEWPyCqcjJgRjoZgS4xzs/YEe8n1A5Ney8J2y5m33fu3SXD65LtF"
        "yvQLLGYBSJ8gNMku/AmFj6ZhodmssXOG9R8Op4qqJUOnDYEtfouHu7Gz4D8ytJ4D0BQ9IqtwMmJGOBqCLTHOzdoT7CV/eVb8ngG4"
        "9NgRz1z+HFoz8MFjvt/6PYCmU1zpQQLyCMHPHZC/xLXM/1YWgOSRqktrsC8kM41jXhi9cM0HsGWOEVJnubAHSAOnDSBNHBzcDe4j"
        "rD0Bwe8LPp2h9RyApugRWYWTETPC0RBsiWvcrJDQWk5SnGQAEdxDWAfCXfh9gbKMsIXDdu5Rw64/9cb+3Y9yCeIPsR9eXf7KU4ue"
        "yFgZANyNxLVu7ic0wek2DobfEmB1IlwiaEFSoPWcpDkIrP0pd6NwShoczWaNnTOs/3A4VVQtGTptCGzxmz3cjf+L4lfBpzO0ngPQ"
        "FD0iq3AyYkY4GoItcY2btSekgdM4SJoD4B7CCsElgl3zvWe6v7UAnNn3rNfGzUNrDp3Ya1tiG4DU2a5MSEAeIfi5CPlLXGv538oC"
        "kDxSdWkN9pGMlbng6eFLjM9hayhxW50pWkMauPg9Ew1L2MJJiuM3BFj7UfNgmu1Nrc4UrQk+nab1HICm6BFZhZMRM8LREGxcIiTN"
        "YcKBgHUg5kE0WyyY3SlaI2zjgefS2J2m01zpY12+97Puby3sWmaAYHajosFcPzHSyPH/EPxfHL+aNXbOsP7D4VRRtWTotCFw4l5i"
        "HkRTZ7gCL2ZoPQegKXpEVuFkxIxwNASb1YnQBEiKw4n7idmLZotp9jABBL/h/cT0LDUBDOw1cOHNi9CaTjd1yFgZAMkLxGyxgDxC"
        "sKUI+Utca/nfzAKQPFJ1aQ32nW2JbYMeGvBLwy8AzF608TI3nOh27v3CFNdYYNgTVleaPk7I9hbgFHwqTes5AE3RI7IKJyNmhKMh"
        "7Blrf5o+Qcj2EeDkWWp6F5nYHfNgah5IvYtM7Auzxs4Z1n84nCqqlgydNgStsTpTkuK0ngPQFD0iq3AyYkY4GsKeYQWk6WRX9kgB"
        "O/F8YXo/NQEctv9hX91TiRzJTOMBt+wPW+NIt3kgRR4h2NIR+Utca/nfzACQPFJ1aQ1yfPnDF1M/1ODkoq72UofizsWn9zmjb9cj"
        "sAszFj9zxxu3wpa4zsvaEdiICc/nWc9SEwx7yzyIps52s3YELYJPNdF6DkBT9IiswsmIGeFoCHvDPEhInSOyQoIWgRfTQjXDbhFY"
        "XajwM8O+MGvsnGH9h8OpomrJ0GlDsAtcIqSRA9AUPSKrcDJiRjgawt4wDxKSF4jcQ2BzV5q+97MA9gvuZzy0Hjmqazf3va8Ytoax"
        "HqszRR4h2NoR+UtcY/nfzACQPFJ1aQ1ylFfOKykbjV07rc/pT496pnNBZ+RoyqZ6331IfaoeQNMpYvoEFwAa5/7XMsJWhhYel+eU"
        "4tNO7XPa0T2O7ll0YHupvUCEhnRDdV312p/XLDE+f2fF/FgihhbcS5IXus1eFLbgk020ngPQFD0iq3AyYkY4GgIgCuLZR55zzpHn"
        "Ht3zmG7tu/pEf9psiiVi67asW2J8/va/39q4YwNacD9pvNhtdaOwBZ9sovUcgKboEVmFkxEzwtEQbCxIaIID0BQ9IqtwKl346APv"
        "3A/bMT0HDO137qCDjju40yHtpfZjXhj97soF15964ynFp8LWr9tR+wX3g1Ndsu6bDV/D6ZqX1FgiBoD7CElxAJqiR2QVTkbMCEdD"
        "sA3sNXBY//OOPWjgQR0PbudvB6AuWWfU/OfLH794s7J85eYVaME6koYrPNxPAIjrLP+8DAC34I49vgM51v685viHB8KWuN7L2hHk"
        "EYKajshf4hrLX54BIHmk6tIa5CivnFdSNhq/6+D9Dv7s9iVBbxA5rp511avL5wIwDxYaL3PTHTzwzzRp4LD53P7rT7nh6pOv6Rjo"
        "iF0zmfnWv9+c8t6DVbEq/IoieZE721sAEHyiidZzAJqiR2QVTkbMCEdD5x99QfS8B7u1745d4Jy/s3LB5Pn3VcWq8CsXGkd6zB4U"
        "QPCJJlrPAWiKHpFVOBkxIxwNwcaChCY4AE3RI7IKp9KFjz7wzv3H9Bzw8IWPHNtrIHYy8rkR765cMH3UjBEDR2Iv9ZvUd+OODQC4"
        "j5AUB6ApekRW4WTEjHA0dNzBxz984SP9u4ewa4u//+y212/+T81/YLO60oYrPHDBtZ5Js9OwVZfWSB4JTkuMz8994mzY4rd7uYcg"
        "jxDU7If8Ja6x/OVpAJJHqi6tQY7yynklZaNhywxw4VcWaJwLmxlJc9huPev2e869DzleWPL8za/eBID7SYPqlcqaaD2H7cRDBz9z"
        "+bPd2nfHnsla2Yffe/Dxj3TGGZoJaBzlNXvQ4BMpWs8BaIoekVU4VcWqPl730biTrsEeyFiZ+968+5nF02HjXtJQ4mFFNPhEitZz"
        "AJqiR2QVTkbMCEdDsLEgoQkOQFP0iKzCqXTho5t2bNIveVygApxGPjfi3ZULpo+aMWLgSOylfpP6btyxAQD3EZLiADRFj8gqnKpi"
        "VW9889odQ+4ihGB3mrKpkhfHvLfyHdjSx4lNp4vCFhZ4vgm2Nfd/17V9Nzi9s2L+qOcvQzOC+nv8yC8ENfshf4lrLH95GoDkkapL"
        "a5CjvHJeSdloAFxE/E4/dkKy8L+Sdm2wABy838Hf3LcCOT43/vW3J86BzexBXRsZbCUnXlV6sU4JxV56s7I88s8Sk5kAWJA0jPMG"
        "nm2i9RyApugRWcWf9uy/Ztzxxq2ccwBWF9pQ4g0+laL1HICm6BFZhZMRM8LREGwsSGiCA9AUPSKrcFpTvbpv1yPQmpHPjXh35YLp"
        "o2aMGDgSe6nfpL4bd2wAwH2EpDgATdEjsoo/x2Tm+U8N+9z4F5oRJK72QiTBJ1OwfXHXssMP6AunOUtfum7ONQC4j8Rv9SG/EMT2"
        "Q/4S11j+eWkAkkeqLq1BjvLKeSVlowFwEfG7/HAS11n+19MAKKG/TKsnhMBpdfWqE6ccB6eRgy5/euR0/FFzlr503ZxrYMv0d7nW"
        "W7SeA9AUPSKr2BemvPfQlPcfgq3pDNH9lUnrOQBN0SOyCicjZoSjIdhYkNAEB6ApekRWscdGPjfi3ZULpo+aMWLgSOylfpP6btyx"
        "AQD3EZLiADRFj8gq/rQtdT+HHzi6Id0AIHOUq2mIWPBICrYFN743+FAZTk8sevy+t+4BwDqQxPU+5BeC2H7IX+Iayz8vDUDySNWl"
        "NchRXjmvpGw0AC4ifpcfTuIayz8vDYAQ8su0ekoonFZXrzpxynHYSb9uR31866duwY3WfLdl3fc136fNdOeCzsf0HCB5JLTmmtlX"
        "v7JsDpoRsAChCQ5AU/SIrGJf4JyfM+2sL3/4AgD3Ey6C1nMAmqJHZBVORswIR0OwsSChCQ5AU/SIrGKPjXxuxLsrF0wfNWPEwJHY"
        "S/0m9d24YwMA7iMkxQFoih6RVewLD7xzf+nCR9HMhfht/oIpSXA0m33Vy+ceNQxO0QWTp36oAbC60oaxXuQXgm2dkL/E1aZ/XhqA"
        "5JGqS2uQo7xyXknZaABcRHyiBCf/a2lxnQmge4ceqyavRY6KqiVDpw1BC0ro4tuXHNmtH3K8u3LB5PmT/lPzH7Twit5Rgy6fNOz+"
        "oDcIp9pkbf+/H1GfqgfA3SAZNNMUPSKr2AXO+YIV81//+tW1P69JZZu6FHYZfJhccuLYHh16ojVrqlcPfuR4xhkA7iMkxQFoih6R"
        "VTgZMSMcDcHGgoQmOABN0SOyit3ZUvdzbbKWc373m3d99v2n2MmssXOG9R8Op4qqJUOnDcEucImQRg5AU/SIrGLXNu3Y+PG6j37a"
        "/hMh5JBOh5x9xNCiQBFas7l205GTDuecA0iO8PreSpMUB/DUyH+MGnQFnG557aaZnz8PwDxEaBzpRX4h2N4J+UtcbfrfSAOQPFJ1"
        "aQ1ylFfOKykbDVvTEDd+ZYEkuOtHS4gx2MaddM2UizTkmL101vVzrkWL80Lnv1jyEnLoH5bev+DvaM1h+x/23k0fdgx0hNPk+ZMe"
        "+2gqmhGAo5mm6BFZRWu2N2y/YubIL6oq4OQVvY9eVHrF8VeiNZfOuPiD1e+hmQsw0UxT9IiswsmIGeFoCDYWJDTBAWiKHpFV7MLP"
        "ddVTP9Te+vebvzT8gl2YNXbOsP7D4VRRtWTotCFoDfcT7gKNcwCaokdkFa1pyqZufe2Wl5fNZpyhhd8tTb1YHzFwJFpz3EPHrtuy"
        "FkB6sCiusegOBuD+8x648bSb4DSm7Io3K8sBZI90JS/0IL8QbN8f+UtcbfrfaAIgeaTq0hrkKK+cV1I2Gr+rU7DTkruWdgp2Qo4b"
        "Xr7upS//iRbv3Pj+iYcOhlNF1ZJznzibc45dOKffuS9H5sLpu63fDXpwAHaiKXpEVpEjbabPmHrqys0r0BpCyIwrnr94wCXIUV45"
        "r6RsNHaiKXpEVuFkxIxwNAQbCxKa4AA0RY/IKlrzufGvUc+NqE/V43fNGjtnWP/hcKqoWjJ02hDk4AGSvNDre7uJ1nEAmqJHZBU5"
        "OOfnPf23xd9/hhyU0HdufP/4Q05Ajmtnj3t52WwA2WIXTXCh2gJwy5m33fu3SXC64Onhn3y3CEDmWDF1jgf5heCX/ZG/xFWm/40m"
        "AJJHqi6tQY7yynklZaOxa70795419uXenXsjR9bK9rnn0O0N22Er8BX89MhmSiichj917uLvP8PvWjpxeXGXPnA6/N7eP9dVo4Wm"
        "6BFZRY7HPpo6ef4k2FhHmjnSxb1E2GK5V5pgaFboK1w5eW2hrxBOtcnag+7swTlHC03RI7IKJyNmhKMh2FiQ0AQHoCl6RFaRo7p2"
        "86CHwommBHKwQpoZ4PIuysA2a+ycYf2Hw6miasnQaUNgS17k5R40435idRbgQvCxRlrHAWiKHpFV5Jiz9KXr5lyDX7lgdRZgcqGG"
        "gaPZaX1On3ftW8gx5f2Hprz3EADrAMr9xFVlASg58Sr9ksfhdIom/3tjJYD0Se6mU93ILwQ79kf+EleZ/tebAEgeqbq0Bjk+XvvR"
        "7W/cAicXdXWQOvTu3OfMvmcOOeIcgQpozZylL1035xq0OLn3KW9dvwA5xr54pWmZ+F2jTxhzavFpcLp0xsUfrH4PLTRFj8gqchxx"
        "X5/NtZsAWD2Ehit9cOFX4jrTP7cJHM0eVaaq8tXIceSkwzft2IgWmqJHZBVORswIR0OwsQJC4xyApugRWUWO21+/5dl/zYAte6Qr"
        "c6zICikIuAtcIgAK72+AiWazxs4Z1n84nCqqlgydNgS2+D0SdxPsJKg30joOQFP0iKwix5DHTl/641IAbD/aUOLjEgHg+Tzj/SgD"
        "wCt6N5dudVEXnJ5ZPP3ON24DwDpSqwsVV5kAzj/6grIxs+DUf/KRP21fD6BpiCd9vIj8QrCjM/KXuMr0v54CIHmk6tIa7Dt1ybpB"
        "Dw7YGt+KFmNOGPvYpdOw79zxxq0zFj+DFpqiR2QVTptrNx1xXx/YGq/wmYe4sBOpLOlabwE4/+gLysbMQo6zHz/zyx++QAtN0SOy"
        "CicjZoSjIdhYAaFxDkBT9IisIkff+4qrazcDyBwjpoZ7kaPw/gRMNJs1ds6w/sPhVFG1ZOi0IbDF7wlwN8FOgnojrWMANEWPyCqc"
        "sla2y837mcwEkDrPmzlahE3YYgWmJ2FbNXlt9w494FRWMXPC3PEAWAExi13ur7IATi0+rfy6t+HU647utclaAKnzvZmQiPxCUNsZ"
        "+UtcZfpfSwGQPFJ1aQ32EYtZlz17ycI1H2AnE864ZdKwydh3Hnwnqi18BC00RY/IKpy+Wr/sTP002OJ3BHiAYCfeD9KeigyAgb0G"
        "Lrx5EXJcOkP5YPX7aKEpekRW4WTEjHA0BBsrIDTOAWiKHpFVONWn6nve3hW2xtE+8xAXchROTsBEs1lj5wzrPxxOFVVLhk4bAlv8"
        "3gB3E+wkOLWR1jEAmqJHZBVO1bWb+95XDFvDOL/VVYCN1rKg3gjb0ru/Lu5cDKeyipkT5o4HwApINiR6FmcA9O8e+uz2z7ETxlnH"
        "8e0YZwCSl/myfVzILwS1nZG/xFWm/7UUAMkjVZfWYF9Im+lxL0XerCyHjUuENHIAE864ZdKwydh3Hnwnqi18BC00RY/IKpy+Wr/s"
        "TP002OJ3BHiAYCfeD9KeigyAgb0GLrx5EXJcOkP5YPX7aKEpekRW4WTEjHA0BBsrIDTOAWiKHpFVOK3fvj40+UjYEjdIrBNFjsLJ"
        "CZhoNmvsnGH9h8OpomrJ0GlDYIvfG+Bugp0EpzbSOgZAU/SIrMKpKlY1INoftsRNEiuisNE6FpzaCNvSicuLu/SBU1nFzAlzxwNg"
        "BSRzvNv7QRrAgR17fTtpFXZSl6w78I5usDVe5Td7CsgvBLWdkb/EVab/tRQAySNVl9bgT1tTvfraOeNWbPoWNtaJsnbU9R8TwJgT"
        "xj526TTsOze/etMLS55HC03RI7IKp821m464rw9sjaN95iEu7ER6IelabwG44OgLXxjzT+Q4+/Ezv/zhC7TQFD0iq3AyYkY4GoKN"
        "FRAa5wA0RY/IKpyMmBGOhmBLTJBYB4ochZMTMNFs1tg5w/oPh1NF1ZKh04bAFr83wN0EOwlObaR1DICm6BFZhZMRM8LREGyJCRLr"
        "QGGjdSw4tRG2pROXF3fpA6eyipkT5o4HwApI+nSPr7wJQIGv4LVx5dhJTXzr6JmjYGu4XrL2p8gvBHVdkL/ElVn/aykAkkeqLq3B"
        "nzOx/M4Zi6dbzIKNdaSNJX7PZxn3VxkA8mEnzb/hXeQ46u9HbPjlJ/xpmqJHZBU5jpx0+KYdGwGYPYXGEgkCfuX63pRmJ8HRbOrF"
        "j48dfBVyHHFfn821m9BCU/SIrMLJiBnhaAg2VkBonAPQFD0iq3AyYkY4GoItMSHAiihyFP49DhPNZo2dM6z/cDhVVC0ZOm0IbPH7"
        "gtxNSBOHAC4SAMHSBlrHAGiKHpFVOBkxIxwNwZaYEGBFFDZay4JTG2BbOnF5cZc+cCqrmDlh7ngArIAkL/MHnmnE7xNQf28BXMgz"
        "BHVdkL/ElVn/aykAkkeqLq3Bn7NgxfzLn78MLeJ3BnmAuJdnfG83ASjwFayfskmgApymffzYpLfvxZ+mKXpEVpHjsY+mTp4/CTa2"
        "H830E7mPCFss97+zYGhW6CtcNXldga8ATjsadxx8V0/OOVpoih6RVTgZMSMcDcHGCgiNcwCaokdkFU5GzAhHQ7AlJgRYEUWOwr/H"
        "YaLZrLFzhvUfDqcvqirOmXYWbMmLfe7KrKvKBJDtJ6bO9Qb+0UjrGABN0SOyCicjZoSjIdgSEwKsiMJGa1lwagNsSycuL+7SB05l"
        "FTMnzB0PgBWQhhsDBQ8ksDv10QIQ5BmC+i7IX+LKrP/VFADJI1WX1iBHeeW8krLRcPKKvsW3L+nduTdyjH/lhn9+UQZb01Bv+ni3"
        "UMMCTzTA9uZ1808pPhVOGStzln76vzdW4ncdtN9B67ev55xjZy5wkZAUB6ApekRWkSNjZU4vPWXl5hXYhWdHz7x4wCXI8cY3r1/1"
        "4hjsRFP0iKzCyYgZ4WgINlZAaJwD0BQ9IqtwMmJGOBqCLXFzgBVR5Ch4MEGSHMDzV5ZddIwCp3Vb1h730LFoTbaPS9jCaB0DoCl6"
        "RFbhZMSMcDQEW+LmACuisNFaFixtgG3pxOXFXfrAqaxi5oS54wGwAmJ1d4lrsrAV+Ar+dtTw3p17m5a5YtO37696L2NlYGs605M+"
        "yYP8QhA/APlLXJn1z00CkDxSdWkNcpRXzispG40cR3br98mti0VBhFMqkxz8yPFVsSo0c6Hh2oDVWQg+lqDbGIBz+p37cmQucuxo"
        "3FFSNvqz7z9FayihVxx/5ZQLH3mxouzOebejReo8X/YIMfBUA61jADRFj8gqWrMtsW3Uc5cuW78MTl7R+/CFj4w5YSxac+E/zlu0"
        "7mM0cwEmmmmKHpFVOBkxIxwNwcYKKI0zAJqiR2QVTkbMCEdDsCVuCbIiihxBPUG3MwCPKlNV+Wo4Mc4GRPv/uO1HtIYHCUlwAJqi"
        "R2QVTkbMCEdDsCVuCbIiChutZUEtAdvSicuLu/SBU1nFzAlzxwPgfkKSHLaTep9cNmZWB6kDWlTFqi6dcVFVrAoAd5PErUEeIMgj"
        "BPEDkL/ElVn/3CQAySNVl9YgR3nlvJKy0WjN+NMnTB4eRY4Vm749feopWSsLwNpfaLgu4KlIexc2ASCEfHjzovCBx6I1H6x+/+Vl"
        "s5f9uLQmXgPARV29OvY6qffJV55QckTXI2F7+L0HH3n/YdhYe9pwbSDwdAOtYwA0RY/IKnaBcz5/xdtvfP3amp9Xp7JNBxQecNzB"
        "x6snXd2jQ0+0ZsWmb0/WBnPOAXA/IUkOQFP0iKzCyYgZ4WgINlZAaZwB0BQ9IqtwMmJGOBqCLXFLkBVR5JCea3StNwGMHXzV1Isf"
        "R451W9aqs65atXklgAM79rr2lOunLny0Jl4DgHsISXMAmqJHZBVORswIR0OwJW4JsiIKG61lQS0B29KJy4u79IFTWcXMCXPHA+Ai"
        "IVkOoGv7bl/d/Y3kkeBUFas6/qFjM1YGQGqYLzPIjTxCkDgA+UtckfXPTQKQPFJ1aQ1ylFfOKykbDVvjaIkw7n8pCRsldP4N7554"
        "6GDkePwj/e/z74Mtc5y76SxvUEuQRg6guHPxJ7ct9rsl7FrWymbMjM/to4Qix62vTXj+8+dgyxzjdv1g0joGQFP0iKxiX7CYddZj"
        "p3/903IAPEC4i9A6BkBT9IiswsmIGeFoCDZWQGmcAdAUPSKrcDJiRjgagi1xa5AVUeTwLmzyfJYGcEinQ76+91vsQl2yjhBS6CsE"
        "cO9bdz+5aBqaEYCjmaboEVmFkxEzwtEQbIlbg6yIwkZrWfDRBGxLJy4v7tIHTmUVMyfMHY9mFGBodtc5d99x9l1ozYhnL3l/1bsA"
        "skeJyUv9yCMEiQOQv8QVWf/cJADJI1WX1iBHeeW8krLRALibxCcXAKA7WOCJBpLmALq27/bFXcsKfYVw4pwPe3Lo58a/YGu8UqI7"
        "mG9+Crah/f42a+xsgQr4QzjnY8queOvfbwLgAcJdhNYxAJqiR2QV+8Lk+ZMe+2gqbE3net1LMrSOAdAUPSKrcDJiRjgago0VUBpn"
        "ADRFj8gqnIyYEY6GYEvcGmRFFDlcP5jS842wvTv+gxMOORG7893W7wY9OAA70RQ9IqtwMmJGOBqCLaR2pTwAAAg1SURBVHFrkBVR"
        "2GgtCz6agG3pxOXFXfrAqaxi5oS549GMABzNXhjzzwuOvhCtufetu59cNA2AebCr8SoJeYSgoSvyl7gi438lCUDySNWlNchRXjmv"
        "pGw0AO4m8fsLYXN/k/G9noTtomOU568sQ44tdT8f//DA2mQtAB4giZsK/K8nXd9nYRtyxDkvjCnzuyXsvVgiNuzJod9tWQeAtacA"
        "aC0DoCl6RFbh1JRt8ope7I2nPnninjcnwmZ1FxquCQa1OK1lADRFj8gqnIyYEY6GYGMFlMYZAE3RI7IKJyNmhKMh2BK3FbAiilwM"
        "walx+gsDcFT3/h/f8qkoiNidM6aeuvynr9BCU/SIrMLJiBnhaAi2xG0FrIjCRmtZ8JE4bEsnLi/u0gdOZRUzJ8wdj2YUYGhWevFj"
        "Vw2OoDXXzh738rLZALJ9xeTlEvIIQWNX5C9xRcb/chKA5JGqS2uQo7xyXknZaADcTeLRQrTwz24UV2Vhe3b0zIsHXIIc8799+4qZ"
        "I2Eze4vJS/yB6Q10mwXboZ0OfXrUM8f2Goi98eUPX5S8eOWWup9hazrD6/46Q2sZAE3RI7IKpycXTTt0/0OHHHEO9kDaTN9dfufz"
        "nz8HG/eThuuCrCMNTonTWgZAU/SIrMLJiBnhaAg2VkBpnAHQFD0iq3AyYkY4GoItcXsBK6JojfvrjO/1JGwXD7jkH5fPcFEXfldZ"
        "xcwJc8ejhaboEVmFkxEzwtEQbInbC1gRhY3WsuCUOGxLJy4v7tIHTmUVMyfMHQ+AuwgxOYDBh8oLbnwPOZqyqX6T+sYSMQDpU71N"
        "Z3mRRwgauyJ/iSsy/peTACSPVF1agxzllfNKykYD4G4SjxaiBUnywOMJWs8ABL3BL+5a1r1DD+S44eXrXvryn7A1lkissyDNaKC/"
        "MNgIIcOOGj7+9AlH9zwGu/PdlnX6h6Wvf/Ma5xw2s4/YeLkU1OK0lgHQFD0iq3AqXfjoQ+8+cPXJ19wx5K52/nbYBcbZ/G/fvn/B"
        "pB+3/QgbF0njVZJ1oAtAcEqc1jIAmqJHZBVORswIR0OwsQJK4wyApugRWYWTETPC0RBsidsLWBFFqxikZxtc603YBh006PERTxV3"
        "LsauzV466/o516KFpugRWYWTETPC0RBsidsLWBGFjday4JQ4bEsnLi/u0gdOZRUzJ8wdD4D7CElx2KZc+Oi4k6+F0/Vzrp29dBZs"
        "DeOD1gEC8ghBsivyl/htxv9yEoDkkapLa5CjvHJeSdloANxN4g8UYicuw5SebwBHs0EHH/fe+IWUUDglM42Dpxz/w7YfAGSOcacu"
        "8ZMk989Nur7LYie9O/c+s++QY3oOKO5c3KXdAQFPgBKazCRjiVhVzPhmw9cfrfnwmw1fYyeZY9ypi/wQEHw4TmsZAE3RI7IKp9KF"
        "jz7wzv0AAp7AeaELTutzer/uR3Vtd4DH5c1YmZr41nVb1i0xPn+zsnxz7Sa04AHSOCZgdRdgCz4cp7UMgKboEVmFkxEzwtEQbKyA"
        "0jgDoCl6RFbhZMSMcDQEW+KOAlZEsQskyQNPJeh2Bhsl9NQ+pw3td+4xPQf0LDow6A1yzrc3bK+KGV/+8MUb37z+3ZZ12Imm6BFZ"
        "hZMRM8LREGyJOwpYEYWN1rLgw3HYlk5cXtylD5zKKmZOmDseACukoKC1DAAhZMSxI8edfE1xlz6MsW82fD11ofbJd4tgyx4uJq+U"
        "kF8Ikt2Qv1w/mtIzCewBtp+QuK0ATt4FKc/nTdgzmUGe1AV+NONwL0t7P0iRJMfe437SdI4vc6wHtsBTCWGjiX3HPExMXeRn7Sha"
        "BJ5KCBtN7BaB1c0lbDKxWwTxaDvuJtg1Ws/8cxqFn0zscwTxaDvuJrCRLC+4tw4Mu2V1d6WG+wLPNMDk2DVWSBtuDPIgRX4hSHZD"
        "/iJZHtDitI5hd9KneJvO9uE3TASejAtbLOyB5OhAtq+IFiTF3RVpz5dpkmDYM9xLMoM86ZO8XCJo4Vnc5H03hX3B6iKkT/Nm+7nh"
        "5Fnc5H03hd0xe4vmIS7vuynsjtlbbBwbwG4xeD5t8vyriaQ4dsfaX7AOdLmXpbE7Zm+xcWwAO5HKGlzrstidpnN86ZO9rh9N/0sN"
        "pJGjNWx/ofHKACuiyDsEqW7Ia8JG0z+7kdYy7Fr2KHfyUj9cBDlIgkkvNgobTfwOF2ka4k2f5EUuCy4jK36XFX4whW0WLORiRdTq"
        "6coeLpqHi1wk+A0G37yk+6s0doXALBatboJrbVbYYoHBgYB1FMzDXNl+bvMgF1rF4JuXdH+Vxq5ZPV3JyyUWpL55SfdXaeya1dOV"
        "vFxihRR7hmS4+HVGXJMVNpqkicOJF9Dsoa5sf7d5mAjANy/p/iqNXbN6upKXS6yQYic0zvwvNQo/mdi1zAB3SpFA0Yw0cs+nTe6v"
        "06SRowVrTzPHeTInerhIkI8Imroh71kQfjZJgiMXBesksA4Uv4tus+h2Bo5WuInVU+AiwW4x0B2MJBlJc1iASLhEWAfK3QS7Q+sZ"
        "3WrBwm+5YHUWeAHFrywI2yyS5MhwuAn3EdaRcpFgD9B6RrdasPBbBKwDZZ0EEPyK1jO61YKF3yJgHSjrJIDgj+CgtYw0cpJiIIR7"
        "CetAuUTgROsZ3WrBwm8RsA6UdRJA0AoOGrPoDgaO3xLA9hdYO4rf4KAxi8Y5KFg7yooo8hpBU3e0adPmL48g3R1t2rT5yyNId0eb"
        "Nm3+8ggyPdCmTZu/PIJMD7Rp0+YvjyDbA23atPnLIzB7oE2bNn95BGZPtGnT5i+PwOyJNm3a/OURWD3Rpk2bv7z/A3/b5+x4o3cv"
        "AAAAAElFTkSuQmCC"
    ),
    "rebirth_side": (
        "iVBORw0KGgoAAAANSUhEUgAAAFoAAABUCAIAAACNwLclAAAgAElEQVR4Ae3BB5RV5eEu7vf99j5tOsPQe1UQkaKIYkFFRUVRVDTR"
        "RLFrgjH+kmhMYkmsUUNUEEWxogYGCyAgKCKiglE6ozTpwzBDmT6n7f29/zMDRwcDSO7637Xuuus+D19aWmoIEg5hCMcAwj4SUkgY"
        "Q6RIBrBoQEISQNQjQMACICEAEkgIoAOFqOU7/T+d1QYHc8o5P3tx3CMAiHqOw6DrkLKi51vft2jEkI5jAEnwfOv71rcyhgHHBIMu"
        "Id/aeDzhGOM4promWlpSGgi4e8or1n71SbxmdzQaTcbjnm+rtm93QyECIiBBtLKS+PqKUpIACBjCEPUkpBlDNJBgIAMQ8ACQkNBA"
        "IIn9JOxHEPtJ113zUPWSp3Ewi74qym+SSdQzpOsaxyDFs/A8C0ACCUEEXcdYyRBW8H0JIEHSdega/IgvWsFaWMlaS6CmulrC8vnz"
        "Pp35JgBDpBCEZOXzrVWlIAkIIECCAARAAIh6BvtZEo1JBASCkEACEkDUE0CkEBIIfVvq33tWaxzMqedeNXHcQ2hA0jEMuATg+bBW"
        "giQQMAYkJVjJkAB8KysRMIaOoesQB/ItfCtZWaUARD0hWhd78varQEcACAEUBMt/rS5DI4YgIICoRylI+aIFSPjCPgQM4Ysg6kn4"
        "Hol9JAcQYAEBBC7v1QIwgCEdgGggeYD/7drvHMcgzXVMwDVW8n0JWLVizZw5X65atSk/P2vEiNP79e+RmZllDK3k+xaAIR2HjmMI"
        "oREr+r61krWQhDQSn82a/fE7LyOFgGAhSJxcVIZ9BBAECECgZAwI+IIAA1gQBCUCFgCJfSQDEPV8pFAQAZCysr6/e+fOki3bt6zd"
        "UPjabK98E2AAAxD7+ZI/9Pyhffp07dGjU5fO7XPzclzXBRFwjG9taemuJx+ftHhxUV1dwnFMs+a55557wvCLB3do38ZxHN9XCknj"
        "0DHGUGhEoO/Lt1aC6kEAARKfvT/j4/deR5oAQZy8qpSAIYzkgyIBEAJAwCE8IcUAJHyBAAELop4AgvgxIRmPV+7ds33jlo1F67eu"
        "37Jza0nV3uramrpENAoQPyZjWNAsr1mzJp27tD22V8fefY5q365ldk5OPJ54YcLUd6Z+sntXBVFPZIsWTfr3737xxaf16dsjJyfb"
        "CgSMoeMYQ+FA1sKzslYNIIn1UFcbe+L2n4Mu0qws31ldKsACAYCQwCQakNhHACSQxH5CPQKSA/hoQKKB73sVu3eXbC5evvDrlYuW"
        "l27bmUwmYeUCITJIBgEXMCQAK3hQQooDcclDvfymOT17dhx63sCex3SJRuN3/f6ZHTv2ZFh1cJyEtMPaqBQMhzp2bHH1L4aefHLv"
        "goJ8Nxg0hOsYY0gIjQj0ffnWSrBWKQBIAvhi9ux577yMBoIEsLCoDCkSSKQ5kkNZ0AORIuxHHEAABBAphHw/kYjvLdv94eSZSxZ8"
        "tXvHLllrgAAZAAqM6eo4HRwnnyZiGAQBJKVaaZe1m31/g+/vlfWFJGSB3NzMbt3a5ublfv7ZikQs3sN1R4YjWeR7sdhKL1kjyTA7"
        "O/PMs46/4abhLVo2dxw3FDCBgGMIgqSQ5lt4vpVgrawEgEhhTU3dU3deIxANBLGwqAwpElJINCbUI35MCFC+YJFCEJAEVleUfz3/"
        "iw/enLGreFcilrDWBslOxvQNBHq6gebGBAEDEGAK6glQCuADMWmb9Zclva+SiXKJhqZBMullA5eEw2cFQwRi0r+TyXmJ+Cbfp2Ew"
        "GDjjzL6jR1/epWsnQzoOIQgwFNIE+r58myJrJYCoJ+Ch60fACaCBIM4s2umBnuALLuEQSUEkUoQUAQRAHJzkAElrizdt/nDyzGUL"
        "l1bsLvc9Pwfo6LinBoMdHJNNEwFckjgcCySlOqnM2s+TiVWeV2otAAOcGQxeGAo3MwaAgFpph/U/jMdXeF6N1KxZ3j1//uWQc08j"
        "jWtAyBCOYwhhP3q+PN9KslYS6hEQPnt/xoIZk9BAAKesKqUhGlAKUwnQB5EiETAAAaGeBYQUgqgnAUgmkxtWFX04eVbRv1dXV1S7"
        "UgfHGRAIHuO6rYwJkcTBEXAIhzREyHUCjpHgS3Frd3r+ykTy03h8recVGHNNJKOn67r4gQfslp2TjH8YjRvXuf76868ZdVFeXp4x"
        "hEAy4BpSSJOY9Ky18q31fFlrAZKoral75vfXkg4asHB1GVIICCAggcT3BEAAQfxAQgopyUsk1q8senv8mxu/3ZSsi2WQXV13aDDY"
        "2XEzSRyMQziEAwYMwwYhw6BjmmZFMkIBCb4U9211wtsVT66NJ6bWRjuQJ7mBPBo0EnRMVtAsjyf+Ul6VBE4edOydd155TK+jjCEB"
        "Eo5jCKER38L3JQiAhH0kPHDNRQoEDSiIhavLAAggsY8kkkiTQOwjAA7284BkIr59w5YJDzy9Y1Oxn0jmkCcGgsPD4RzS4McIEDBE"
        "tsMslyFDlyTqZYVD+dmRoOugEV+KerYsntxRGa1NeJ6VldCAQEEk0DRgNscT1+2uqLJq2brg9ttHXHrpOQKNIQDH4KAkWskqBRAE"
        "zX932oIZrwMEwMLVpSCRIgEEAckBXCgBikSaBEIgATiS53mb1298/v6nd2ze4SWSLcgzg8EzgqEIaXAQIYMc12Q7DDAFKcR+LZtk"
        "Z4aCJH5EgoV8q4p4cktVtKw2YSUAYddplxkIWbvH85+orPkklvBDgUsvPfXe+24KBgICCeGwBHoWvoVnUVkdG3v7FTAGIAtXlxoA"
        "hBVB7Cc5gEsJSIggsY8EEoCkTd+s+dfTr61Z+q2X9NrQnBMKHe+6ucYQP+YSmY5p4jJoYEjiAAHHadkkOxRwcGieVcy3O2ti26qj"
        "dUm/U25GroNYPFln7cJY4omq2j3SCQOOeuD+G486qhPSPM9zXReH4FtIsoKsPp427dPprwtg4epSgCAOQhJICPsREFLIki1bZr32"
        "3uezP4vV1jUz5rxQ6AQ30MQY4gAEwoa5LjMdBgyJHyOZnxXJyQg7hjgsCQlr90QTJTWxdlmheCwRT3qeUOL7t++t2uL57Tu0/M1v"
        "Lrv4kjOJH9TVxTIywvgxWivfyloJkFRdXTfmt9cIYGFRGQQHAkDCFwSAhAAIKSS+Jwmoraqa+69p86Z+WFG2N0KeGwydGQo2oSEO"
        "YIiIYdOAiRga4qAcY9oW5AYcgyNjpZhva+tiNdGEb60AT/ifvVVfJZLB7IwLLhj417/d6joGjSSTnrU2FAriB7SCJM+3EqxVTXXd"
        "mNuvguuysKgMKRIBgagnAiSsIJBEPaEeId9funDx5LGTtm/YFgb6uu7V4UiuMcQBCGQ6bBE0QUMcAomQ67bOzzGGOGK+tSXl1bGE"
        "h7TCutjL1dEy6Kij2k564285OVmOIQ7keb7rOkizFlYpsFZWslbz3p76xQeTWVhUhhQJ9QjiABJAEPvQ92urqsbc9ei65eu8eKK9"
        "4/wmI6PAOA5+LMdlQcAEDYlDCrhO85zMcDBA4ghJqIsndlfVJn2LtA2e/1BFzfJEsmXL/Pvvv/7UU/tEIhGQBAQRP7DWwji+pW/l"
        "C5KsBSErVVXHx935cxauLgUIAhL2I4gUCQ4EwAIgAdTVVH/wxrQ5/5pVXV7V2pjLQuHjAwEDEAfIcdk0YEKGxOFEgoFW+dmGxBHz"
        "rUrLq6NJTxLSqq3+XlkzKxrPysm4+OJT77jjyry8XOxDEAdI+Eha+gIEK0gCAUHA46Mu5JTVZSQOICGFxPckAvFEvHjjlrF/fLJs"
        "e2nE808NBi8KhXNINEIgw2GzgAk5NDgc15jczHCTrAiOmKR40i8pr/Kt0IgvvFkbfa0mWuU6Xbu1mTDhrhYtmhljABAAQfxAgG9V"
        "UuFlZwQBSCJhSF+aW/g+C4vKkCIhhcQ+EgGBgBzCF0Du2blz9hvTPnhzlvW8Hq57eSjc3XWJH5iAG8rNbBati0AGPyESDBTkZIQC"
        "Lo6Yb21lbby8NioJB1qaSD5dVbcy6UUioQkTft+n79GRSAQA0YAkhAYCIAioqPON4wqCEHRphcrqBAuLygBIcCASEiwI4kes73+7"
        "ZMWEB57ZVbwrKPwiEhkUCIRIpNFxIs3zOl4wSNM+RjQOCYfVJCvSNDsD/41E0t+xt8qzFv9ht29fqIkW1kaNY64ddf711w9r0aI5"
        "GhANSEIABVgrEilWqIqJZEaQEjwLFq4uBUBASCHqCQABC5KoJ1Ts3vXh5JnTXn7X97x+buCKcLit4xA/yOrYqsOFp+YZlL/+vuIJ"
        "HFbQdZrmZGSEgsSRslJ1NL6rshYHk5RmReMPV9Z6xHHHdXngrzccc0x3pBENSNQThBRhv1hSoAk68CxYWFSG70kg8T1BACGQ3y5Z"
        "9sY/Xv1u9XoD3BjJOCEQyCCRltO9fZdRw5od02n3wy/Fvt0oz8dh5WWG87IirjE4YvGkt6c6WhdP4GAELE8kH6usXef5uXmZjz12"
        "y+DBJ7qugwZEGgkJDYQf+BYgrcDC1aVIIfGfJIAgUhZMmz11/OQ9Jbuyybsys9oZ45JIIbM7t+l2yyWthgywW0u23faIX1kDCYdG"
        "smVeVkY4SBwpCTWx+O6qOt9aHMIO359QHZ1WFzPG3PKrS35x9XnNm+WjAXEQwgFIWJGFq0tdQIBP4kASHEiAgM9mzp3y7OTdxaVh"
        "8vxQeHCHVi2zMiKOgVXnay5od8lgN+hWvj2v5KGJsBaHFQkGmuVkBgMOGpEg1DPEf/J8u6e6rjoax6HVSvOjifsqqi0wYGCv3/3+"
        "50f36AoxHHQcBynEAYT9iHqCmFJYVIYUQYCBHMADQKIxafO3a/71zBvffL06mUg65Gkn9x59wyV9OrQKJLyCk451I+HYN9/tfPTl"
        "mk+X4rAItGySnREKgExKUStfCgHWwkoEgo4xBEmHMCQa1MYSe2vq4kkfh2aBTZ5/4+7KSmtbtWl65/+MHDbsrFjCk0Uw6LoOaegQ"
        "3xP2I9IIFhaVIUUCCcCBKFjABwmBRIqUTCa/W/3NuxOmrvpyuayCwUCbVgUXXXTavX++MSs3yzim+sPFO+4dn9yxC4dFsl1BbtB1"
        "qq1dWB19say8OOldGwx3dhwJJAzgGGYF3dZZ4bbZYQCSdlXVVkfjEg5vt7VjqmrnRxN+wL3m2nN/c8fVkXAQDYj9BBD1hHrE9wSQ"
        "U1eXioQAyCU8ASQOJlZbs7tk59effDVv6py9pXscx+TlZZ98cu+bbhoxYECvzGh8z8vTd7/4Lnwfh+AYZmeEA5HQexU1MyqqN8SS"
        "e5LeBaHQ6YFgFok0AkHXdM7N6NokE0DCt2Xl1bGkh59SK82LJv5RVVMlnHBqn9F/GNWzSztCLuEYuAYpBAxhCGE/QtiPLCwqQwMJ"
        "xH4ByoE8MCmS+J71/drqqpWLvv5oygfbNmyrq65zXee447oPHtz/4gtP6+I6VY+9El2xTkkPB5M0rM4Iv1dZM6uydms8mZSC5LBQ"
        "6IxAMN8Y4gctMkNHNc3KDbqS9tbEqupivrX4KZ6w3fdv21NZ6tu2nVr/cvSVF513mgtLgCmAUI+AUE+CQxsyVhJJ13VYWFQGgZBA"
        "ED8m/IDYx/f8tctXfDZz/urFq3fv3CWrcDh48snHjRx2ai8p8uoMU14F3+JAVVZFvj81nlhcE6uzFg0IBMhzg6GTAoFmxmSSAEKO"
        "6dUsu1VWmIBvbfGeqoTn4wgISEj/s7d6aSIZyMkYdM7AP973qyyHhEjiQBJSBMH3E/GEMcyIhPjO6lISviA0IJEiAQTxAwEQSDSQ"
        "UFNZsWzhv99+7q3q8up4NG6tjURCx3Rp+4eWTVt8tz0SiwdIpMWlz+PJMVW12z0f/4FAZ8cZFgof67oZZMe8jC55GRmuIyme9ErK"
        "a3xrBQgQICFFkAABAgQIECDAl96pjb9ZG90LdevV+bHx97drmu3IggRAQIAEEhL2k/USiXjCy8mK8O2iUgAWRGMCCEgGECASP6J6"
        "yWSiam/FZzPnz5s6d8/OXQBcx2Qbc7Qxv8wMnxAKGOw3NxqfUF232fN9HJwLZJC9XPdXmVmntmmSFw4QSPq2rLImlvCSUtQqKtVJ"
        "NVYJKSrVSdVSpVXUqtqqTjYG1Vnttdro+TGpy1Ht7v7HPcd2bh2mBQQQDSQAAoj9JC9ZW5fICAdYuLoUJBoxkgVBQDKAAQSASPEF"
        "kAAciYAgSnv3VJRsL1k899Ov53+1u6QMQAbZzDEnhYJnhkP9Q+7iePL56ro1yWRCOAwCYbKL67YIB0h6gG8VTXqeZCFf8AEf8CUL"
        "WMAKHuQBVvAhK/iABazkAcFw8PgTe97+6N2tciOZxjqoJ9ST0JgA+l4slpDEwqIyHJQggERKvK6ubHtxWXFJrDaWSCa9pJeMx33P"
        "SyY837fJhJeMJ3ZuK9n87aaK3eVIyybbu+5p4eDSRGJ1wquVcGSIegJImoATyM5I1kT9eBIHIolDyMqKHN2jw82/uqxj/+MJ5rg2"
        "RDkEiKSPFEloIBAAZf1Eoi6WZOHqUgAu4QsCAYFEI7G6ulWLlnw6Y/7Gog211bXJeEIQBEkASAKQhIMiCAIQBIAAaFKstbIWPyWQ"
        "GWl1Qo+mvTrVrdlStnpjRVmFrEWDYCjQqlVBfkFuZiQQCLokHNdxjHHqsaBZk9NO69/vhONidHfF2TSgTMe6BlbwLCRIAiA04nnR"
        "WJyFRWUQApQnCASxjwQHArB2edHzf326eGMxAJIgSIJphikgaQwBGkPDesaQoOPQkCAJGBqHTiAUDAcT0XhV6d5EXdRai0NwQsFm"
        "vbsMeuCGQCTUNRhcP+vzj16dVbm70o8nJWVmZQw+8/jhlw5p265F6xb5xnUAktjHEIaUkASLY8xylGlskBAgQYAkAAIkEABBa/1k"
        "goVFZTgoAUTK1PGvzZv6QcXuSuM6gXAoGAkGwsFgRjiSk5OVn5uZn5OZn5ORmxPJyYrkZoVzszJysp2gS9I4BiANCYIgCe4n6Zt5"
        "iz95vrC8ZBck/Aca07xvt/63j8xu1xxkxJjT85tkV9U8/GLhqn8tSMYShnADbrOCvMFnn3jddRc2b9FMIAASKQQMQdIKe5Im5iPX"
        "tSFaggCEekoBIAj1DECb5JTVZYQAAnAoAr5gQRIpDlT4/KQPp8yp2F2e37XtwOuHd+/aScah69JxHNcxruMEXOM4xnWM4xjXOI4L"
        "giCIw6grrypZu3nN/H8veW9evC4GCWnGddoN7nv0FUNyOrYyrgPAkC3D4TOa5TdNerM/Xzb1zdkbl6xLVNY6xsnNyzyuT5erf3nB"
        "cf16hYIhEPsYwiGtEBV3xtgkoAitwX4ClAJISCEBIWQsC4vKIBGwIIn9BBD1pFWLl7zy6HMlW3dmNs8/btQFp1xyVtcmeYATs6r1"
        "rJUACP8FYj8/6dXuqVg5+7Ov3/lwb3GZl0jSMcHsjHan9ek2YnBW22bGcZCWHXAHNS8Y2aHd+qq6L5Z/O3PuwuVzvixZs9UmvGDQ"
        "7dGzwyWXnXXiSb3btm1NEgAJQwD0hJK4CRtlGrkQGgj1rARBqEci4oKFRWU4BEICo7W1Ex98eumCJQnPzz+q3aAHbujdrtXRTZpk"
        "BEJRH3FrfckXfMmTrGABKwEk4QCOoQEM6QCGNIQhDWBIQzikAQqffPX9V6d7ZE6HFi37H9X5gkHh/Bw0QqBdZsbF7dt0y21S7sFK"
        "m3bv+nTx0jmvzly/ZE1dZY0827JV08FnHX/BRad169YxHA4bQ0MawgqVvqnx0MRVEFYQQSFFEiQI9UgEHbCwqAz/STCQTxKQsGzh"
        "oiljJ21dtyWYk9nvNyNbDzwmPyerf0HTgc0KMl0XgC95QsKqzrd1vq3zLcmAMRmOyQ+YDMeEDF1Dh3RIQxpAgFDPt/buu5+a+dHi"
        "3GO7dL/sjEh+LogfcY0Z3KL5sPZtK32DNM/6m0vLxo6btHTG5xU7difjSTfgtuvQ6nd/uenonl3D4VDAwDUwhrU+IYGM0BICQFCA"
        "UgAJ+wQcsrCoDAAlAQJB7CcI+9VVV//rqYmfvDcfhgW9Og+46+rM5k1ygsH+zZqd3qo10iQIEPYzQNhBtgOCJPYhDmClkrq68V+v"
        "3BGNmaDrBIM0xH9oHgkPa9e+Y06ecADf2rq62Io1655/+MUVny5PJpKO43TrfdRlN1/VtnPniGuyI6ZNFnJCdA0rPSMhAAkCCEAA"
        "JAESUhwDTikqQwMJPyYFiJSk7y+b/+nkZydv31TsRIIn3PmzVgOPCWdltMjIuLxzl7xgyJD4Dy6R68IlDqPO9yau/W5DVXXcWhyM"
        "A3TIzjmhefNO2TkR18XB1EajxVtLZk2dW/jSu3t3VTRt3vSGu27qemxv3yoU4CkdAqhHK5R7ToTWSgCRZpWCFBKcvLoMDRzIhQxg"
        "AAMZwgEMBIDAntKdb7827d235vi+3/qkXr1vvCi3U+tM1z2lVev+Bc1CjoMDEQgbZLsgDqnO81aVV7y1cUvM93EgAgFj8kKhbrm5"
        "PZvkF4QjYcfBocVj8Y9nLrj/t3+vqqhu3bbF7+67+Zi+vX2BQOc8pCR9xKxJgBkUICGFaGCVgn04u6jEAQgYyIEACnAoBzKAAQxk"
        "KOv7X3257OH7J5Tu3BvMyexz24h2p/cJhUP54fAVXbrmh8KGRCMOkekgYnAY5YnEjK3F6yqr6nzfs1YAAceYkONkuW7LjMxOOTk9"
        "8vIcGvyUHVt3jP/7S1Nfm05jTj+j/6/vvKp9x/YSrOAYGNJKvugaBAwIWImAQEASBEhI4cJvig1E1HMgQxApIiBAIiA0KN5e/MoL"
        "786e/qnv++3P6Ndr1AXZ7VoY8rx27Y/NbxpxXTQSdpDtwOBwrFTjecv3lm+tqa1IJBO+dRwn0w10zM7umJ2dHQjiyHhJb9pbM59/"
        "8pXtm3dEMsIP/3308Sf2zszMkJBCwiFBWEESAZKArEBAgIQUARC45NutAARISCHqCZCQIoAQUoREIvHd+k133PpQbU00mJd99M+G"
        "dB8x2BjTKiNzeMdOLTMykEYgy0XEgPgJEjxZK/lCQqjykOKQDuvhyBRvKf7b755Y+NHiYCAwYGDPP//1loKCpgBJCCDgMAUpvhUA"
        "EgCtRECABGE/fvnNNqRIaEBIglBPggMBkpBirSrK945/+o0FH38djSdbn9Sr768vzWieHzBmSNt2fZo2DTsuGgSJLBcB4shZIWpR"
        "4+O/IimZSDxx39j3p8yp2FPZqnXBX/56c7/+xwRDIQn1CAjGwJAEJPkCAZJKQT0Jwn78d9EWCRKEepQAEYKEFEkAJACS4rHo6pVr"
        "H3/klZKSPZEWTXpedW6n808i2SE7++w27dpmZRH1shxEDAxx5JIW1T6Swn+lrrbui48XP/anp3ds3ZmbmzV02KBf3/GLcDjoGCNA"
        "wj4kHKYgxbcCQEKAhH0kCCDAL1duggQIgKwEESmSFVIkQUiTled5jz484YvPVsUSyfyj2598/w2h3MyMQHBQq1YnNmsedBxD5Llw"
        "CeJISaizqPHxX4lF4xvXbfrrnY+tWbVB0nF9u9/+P1f16NndMUQDCfsQIGEMCVjJCgRIWCGFkgAjC4CLlq2nJAjaByR+hIAAAsY4"
        "NOazhV8+P27qxu+Kw01z+tw2ovVJvdxwqHNOztB27VtGMsIOMg0c4shZocpH3OLI+Z6/fUvxC/949Z03ZkLq0LH1qJuGn3/hWSAN"
        "YYh9JOxjCJKGSPGtCBkAEiBAEARA4BdffYt9iHpCPYKgMYaGNMaQNExDTV3siYcnzJm9yJPyurQ+5a83RprmZQSCfQsKzmnbtonL"
        "gAHxX6jzUevD4r+wY1vJa8/+618T34lF45lZkZtuu/SiEedkZmU6hgAcg30k7GMgQzq0SFEKQBCQkCIJgAB+8dW3AEgax9AYkoaE"
        "MSANQRKkBS1A1CPgWX06//MXxk75bv12Nxw84fc/b3XiMaHMSLvMrCu6dO6QEXRI/DcqPMQtjlxJ8c63Xpj67qSZu0r30OCX15w/"
        "4srzWrZq6YuhgJHkGBoKgpEVQAiAIQ0BEoC1AkBCgiCkCAK4ZNVGGoIGTAFJpAm0gEAAIlKsKMACO3eWvfXyu+9P+dDzvNYnHXvc"
        "zcOz2jbPCQZPb9ny7DYtQsbgyAhIWlT58IUj4Xnejm0lha+8N7Nw7o5tpYAnlc94/6UuXdsnrJu0cAmXMBSIekKKUI+EYT0AqgcS"
        "KVZCiiCAS9duRwMLECAg0AIkrJgECRHwwISYAJMAQVn79aeLXnzkhbLiXW4kdPydV7YZ1DuUEc4PhUb36N40HHJIHAEBVR7iFsJP"
        "kBSLxoq3lrzx/JS50z/ZU7YX8KyttHb7yUMufm3C455nhf2IeqyHFAmSkEIwBfUkASShetiHX68tFlBTU7N61Yp1a4oqysurq6s8"
        "3wZCocycvNZduvfoc3zTVm2IAyRisUUfzp71VuHaFUWSze3U/ugrLup49pmRUPCyDu37F+SHyFUrVqxd8+2WTZsqysuTyWRuXl6r"
        "1q379Ot/7HHHBYPBzRs3Tn/v3Y3ffRf1rPCD3Cb5/U8a1L5zl1VLvtq+ZXPl3r2xWJRgOJLh+VyzqnjVki3JhCfttrZcqgIsgCt/"
        "9nMIAog0ImVXWVl1TU1eXl5ubhNfgkAipXRnSZu27XzfJ0EQQCAY6NatO+99/Jn335684qvFvu/hEHqdcPLF195y4llDBdRWVU4e"
        "P+bDqZNqq6twoHCT/J5XXtW2Y8fo558umv9xTXU1DiY7J+ekQad8Ov/jWCyG/xUuaaQE/jcgjtiAM849Z+TV4+79XfmuUvxfivhv"
        "kJSE/3sRgOu6Q4cOveCCCwYMGNCpU6fc3FxjTDwe37lz5+LFi1977bVZs2bhQAUFBaNHjx4+fHi3bt2MMWvXrh0/fvxLL72UTCbR"
        "4KSTTjrvvPMGDhzYrVu35s2bBwKB8vLyNWvWLFy4cOLEiZs2bUKDL7/8csCAAWikZ8+e0Wj0sssuO7+azOkAAAx2SURBVP300487"
        "7rhmzZqFw2FJlZWVa9asmT179oQJE3bu3Alg2LBhM2bMwGHV1tYeffTR27ZtQyODBg364osvxo0bd9tttyFtzJgxd955JwH07t17"
        "xYoVOLQPPvjgiiuuqKqqQoMBAwbMnDmzoKAAB/rss8/OO++8mpqaG2644YUXXsAh+L7/xz/+8fHHHwewYMGC0047DY20a9fu6aef"
        "vuSSS3AIVVVV119//dSpU0eMGPH222/jsCoqKo4//vgNGzagkb59+y5fvnzcuHG33XYb0saNG/frX/+aAE488cTFixfjsObNm3f2"
        "2WdL6t2794IFC/Ly8nAwb7zxxtVXX33zzTc/99xzOKyRI0cWFhbOnTv37LPPRiNNmjR56623hg4dikOz1g4ZMqRFixZvvfUWDqus"
        "rOyMM84oKipCI927d1+/fv24ceNuu+02pL3wwgs33XQTAQwePHj+/PlIi8fjy5Yt69q1a0FBARq5+OKLp02btmjRooEDB+IQJPXu"
        "3XvQoEHPPfccDquoqKhXr14zZswYNmwYGgkEAh999NHpp5+OtI0bN9bU1PTq1csYg7Tly5ePGTPm1VdfxWFt3779oosuWrp0KRpp"
        "27ZtcXHxs88+e+uttyLtlVdeGTVqFAGcffbZc+fORdrKVav79+8fcJ1Zs2YNHjwYaRMnTpw2bdr06dPRyHfffRePx3v27Im0++67"
        "b+fOnc8//zzSEonkt2s3dGzfOjc3F2me5wUCgalTp1566aVIi8VikUjk888/P/nkk5F27Y03v/rihPPPP3/mzJlo5A9/+MPf//53"
        "HMzWrVu3bdsGoLi4eMyYMYsWLUIj+fn55eXlzz777K233oq0N99886qrriKA888/f+bMmUgr3l0xfvL0h28f9fOf/WzSpElImzlz"
        "5q5du6699lqkLVj42RPPv/zB5NdWrlzZo0cPNJgzZ84777zz/PPPI61ozcZ/vvLelpWfzJ01HWk7duxo06bNpEmTrrrqKqTt2rWr"
        "efPm//73v0844QSkzVtfdvvPhn+zZPH69eu7du2KtDPPPLOkpARARkbGkiVL0Mg999zzyCOPoMHpp5/+ySefoJFQKJRIJMaPH3/L"
        "LbcgberUqZdffjkBDB8+/L333kPaNxs2fedn3XbeyVeNvPTRRx9F2qRJk0499dQOHTog7Zxzztm2bVuLFi0efPDBU045BQ1WrFgx"
        "bty4CRMmIG3evHlDhgy5+uqrX3/9daT97W9/u/feeydOnHjdddchbdOmTZ07d162bFmfPn2QNmfNznWbtvzu4tN27dqVk5ODtK5d"
        "u3733XcAHMfxPA+N/Pa3v/3nP/+JBuecc86cOXOQ5vu+67oAxo8ff8sttyBt+vTpw4cPJ4DLL798ypQpSHvnnXf+5667zzzt1Kef"
        "fjozMxNpd95552OPPRYIBHBYK1euHDt27IQJE5BWXl6+Y8eOnj17kgRQXV397LPP/ulPf/J9/9lnn7311luRtnLlyuOOO66oqKhn"
        "z55I69+/v6QHH3zw/PPPR9ru3btbtWrleR4axOPxYDCItFtuueX5559HgwsvvHD69OlIq6qqys3NBfDcc8/dfPPNSJs9e/b5559P"
        "AD//+c/feOMNHNbu3bv79eu3detWHJrv+zU1NfPmzZs9e/YLL7yAQygtLX3uueceeuihZDI5ZsyYO+64A2lffPHFoEGD1q1b161b"
        "NxzWAw88cP/99yOtvLw8Ly8Paddcc81rr72GBpdddllhYSHS6urqnnnmGQDnnntunz59kDZv3rwhQ4YQwLXXXvvyyy/j0CoqKi6+"
        "+OIFCxbU1NRkZmYi7YMPPli6dOn69evXrVu3ZcuWkpISx3GSyeT111//4osvIm3ZsmUPPPDAL3/5yxEjRiBt7ty5Q4cOffjhh+++"
        "+26kzZkzZ+jQoZs3b+7QoQMOberUqVdeeaXv+0grLi5u3bo10kaOHFlYWIgGV1111aRJk/BTFi5ceNpppxHAjTfeOGHCBBzaKaec"
        "8vnnnwNYsmRJv379kPbSSy/dcMMNkgD07Nnzz3/+85QpU957773rr7/+xRdfRNq8+QtuvG10i4KmixbORyOXXHJJnz597rvvPqS9"
        "/fbbl112WXFxcevWrXEIH3744TnnnIMDrV+/vmvXrki78MIL33//fTS47rrrJk6ciJ/y5ZdfDhw4kAB+9atfjR07FmmzZ8+eM2fO"
        "448/HggE0OCVV14ZNWoUgPvuu+/+++9HI998883y5cu7d+9+/PHHAxgwYMBXX3113XXXTZw4EWm7ahLLt1aGqradNrAfGvnnP/9Z"
        "Vlb28MMPI+2VV14ZNWrUrl27CgoKkDZ69Ohzzz132LBhaJBMJo855pj169ejkRUrVvTu3RtpQ4YMmTdvHhrceuutzz77LNImTZr0"
        "i1/8AsAnn3xy+umnI23p0qX9+/cngN/+9rf/+Mc/kHb33Xc/9thj06ZNu+iii9BA0gknnLBkyZI2bdqsWbMmKysLh9CmTZsdO3Zc"
        "d911EydOxE8ZN27cxo0bn3zySaSNHTt29OjRlZWVOTk5aBCLxSKRSN++fZcuXYq06dOnDx8+HI0sWrRo4MCBSBs0aNAXX3yBBnfc"
        "cceYMWOQ9uKLL954440APv744zPOOANpq1evPvbYYwngD3/4w2OPPYa00aNHjx07dsSIEW+//TbSPvvss1NPPRXA7bff/tRTT+Fg"
        "fN8PhUK+748aNeqll17CYUkaMmTI0UcfPW7cOKQ98sgj99xzT11dXSQSQYM9e/YUFBQAWLFiRe/evZF29tlnf/TRR0ibN2/emWee"
        "ibR+/fotW7YMDe66665HH30UaWPHjh09ejSAjz766KyzzkLaunXrjjrqKAL485///Le//Q1po0aNeuWVVwKBwI4dOwoKCpB2xRVX"
        "TJkyBcAf//jHhx56iCQOtGHDhm7dugG49tprX375ZRya53l33333k08+ef3117/44otI+9Of/vTwww97nuc4Dhps2bKlY8eOAO68"
        "884nn3wSaatWrerbt6/v+2gwY8aMYcOGIa1Hjx5r1qxBg3vvvfeBBx5A2hNPPPH73/8ewIcffjhkyBCkbd68uVOnTgTwwAMP3Hvv"
        "vUgbOXJkYWEhgKeeemrkyJHLli1b3mDx4sVbt25Fg969e999992DBw9u1qxZNBpdu3btzJkzn3nmmT179gAIhUIXNxgwYEDr1q3D"
        "4TAaVFVVbdmy5aOPPpowYcKaNWsAXH311a+//jrSfvOb3zzzzDPWWqR98803xxxzDIDmzZtv3Lhx/fr1y5YtW95g0aJFyWQSDSZP"
        "njxy5EikderUafPmzWjw0EMP3XPPPUh78MEH//KXvwCYM2fOOeecg7QdO3a0adOGODRjjLUW/8cwxlhr8b8T8f80QhyZQDDYrutR"
        "x55wcs/+J8588+WVixfiP2Tl5J15yZXNW7f5ZMbbG1Yvx6EFguFAKFRXXYn/VU2atejUs3e3Y/vNmjShuqIc/z/hr//65JZ13yaT"
        "SUAAAYQzMtt36RaN1m5dvzYjM7vDUT06Hd2rfdfujhsAQEhg6fatRV8vLtm8IVpd7QYDTZq36tzz2B79BriBIAFBe0p3frvky5Jt"
        "myv37E7EYwQERjKycps0K2jTqUP3fsaYrxfM3vLdN14iZgxTYBitrvKTiZz8fOM4IgGQaNGmQ5PmLTd9szIeizZv277j0b069Tg2"
        "N78AKULl3l2fz3735Uf+jINp0n3I2QPb22QCwj6BYDA3N9cNBEpLSiRL7CewRavWnL6mjNhPACGAaEQA8QMBBIQUEUQjwn4ulAEb"
        "g0mAAFwoAish4SGWtImkjceSyVicBGhMIADHgTGBgHEJB7KO8YyhwxQABEhBBAFBAIkfCICuu+ah6iVP42Dmfr2xVV4Qgm9lVY8A"
        "IVkrax2KJEiBFobT15QBICCA+IFQz4EECAQggKgngIAA4nsCKMgRLCnsR+wXkE1a+oLnWSVtMpGsroomLXzBBIOhgBMOGNelZxxD"
        "kDCOcRyAFFMAgQCIFBfyBJBIM9CaUu9PZ7bBwfQ687o3xt9vKM+X7/myviRDgHRSDH3fpvgCSM5YUybUIyDUI+oJICCkyAGsIAKg"
        "AzmAgKQAgoABLFIIwEAWKRRAKAj4gAdCkkWK78vzVVvnxaMJm/QM5LomEAw4rgk4pDEiXUiu4xsDAzAFxIGkACDAA0CiwXXXPFT9"
        "9VM4mKWrNxCC4Es0TorrGhoDQIB863l+PJGMxhP/H9hAByiG5oR3AAAAAElFTkSuQmCC"
    ),
})
_TPL = {}


def _tpl(name):
    if name not in _TPL:
        img = Image.open(io.BytesIO(base64.b64decode(_TPL_B64[name]))).convert("RGB")
        _TPL[name] = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    return _TPL[name]


def _to_bgr(img):
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)


def _find_icon(bgr, name, thr=MATCH_THRESHOLD, scales=(0.75, 0.9, 1.0, 1.1, 1.25, 1.4), base=None):
    """Return [(score, cx, cy)] of matches of template `name` inside `bgr` (local coords)."""
    base = _tpl(name) if base is None else base
    hits = []
    for sc in scales:
        t = cv2.resize(base, None, fx=sc, fy=sc,
                       interpolation=cv2.INTER_AREA if sc < 1 else cv2.INTER_LINEAR)
        if t.shape[0] >= bgr.shape[0] or t.shape[1] >= bgr.shape[1]:
            continue
        res = cv2.matchTemplate(bgr, t, cv2.TM_CCOEFF_NORMED)
        ys, xs = np.where(res >= thr)
        for y, x in zip(ys, xs):
            hits.append((float(res[y, x]), int(x + t.shape[1] // 2), int(y + t.shape[0] // 2), sc))
    hits.sort(reverse=True)
    out = []
    for score, x, y, sc in hits:
        if all(abs(x - ox) > 20 or abs(y - oy) > 20 for _, ox, oy, _ in out):
            out.append((score, x, y, sc))
    return out


def find_shop_buttons():
    """Cash and gem buy buttons currently visible in the shop. Never returns Robux buttons.
    Returns [(kind, icon_x, icon_y, score, click_x)] in screen coordinates; click_x is a point
    inside the button, to the right of the icon."""
    l, t, r, b = SHOP_REGION
    bgr = _to_bgr(grab(SHOP_REGION))
    robux = [(x, y) for _, x, y, _ in _find_icon(bgr, "robux", thr=0.8)]
    found = []
    for kind in ("cash", "gem"):
        for score, x, y, sc in _find_icon(bgr, kind):
            cx = x + int(round(CLICK_OFFSET_X * sc))
            if any(abs(x - rx) < 30 and abs(y - ry) < 30 for rx, ry in robux):
                continue                      # looks like a Robux button: never touch it
            if any(abs(cx - rx) < 70 and abs(y - ry) < 30 for rx, ry in robux):
                continue                      # click point too close to a Robux button
            found.append((kind, l + x, t + y, score, l + cx))
    found.sort(key=lambda h: (round(h[2] / 40), h[1]))
    return found


def _still_there(kind, x, y):
    """Re-check right before clicking that this icon is really still under the cursor target."""
    reg = (x - 40, y - 30, x + 40, y + 30)
    bgr = _to_bgr(grab(reg))
    return any(abs(hx - 40) <= 12 and abs(hy - 30) <= 12
               for _, hx, hy, _ in _find_icon(bgr, kind, thr=0.8))


def _button_sig(x, y):
    """Fingerprint of a whole item card (picture, name, stock text and button), so the same item
    isn't re-bought after scrolling, while different items with look-alike buttons still are."""
    g = cv2.cvtColor(_to_bgr(grab((x - 45, y - 150, x + 150, y + 24))), cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, (24, 24), interpolation=cv2.INTER_AREA)
    return (g > g.mean()).flatten()


def _has_word(text, words, cutoff=0.84, minlen=4):
    for t in re.findall(r"[a-z']+", text):
        if len(t) < minlen:
            continue
        for w in words:
            if difflib.SequenceMatcher(None, t, w).ratio() >= cutoff:
                return True
    return False


def shop_prompt_visible():
    """True when the 'Selene's Store / Talk' prompt is on screen (you're next to her)."""
    img = grab(PROMPT_REGION)
    img = img.resize((img.width * 2, img.height * 2))
    gray = img.convert("L")
    for v in (gray, ImageOps.invert(gray)):
        text = pytesseract.image_to_string(v, config="--psm 6").lower()
        if _has_word(text, ["talk", "store"]):
            return True
    return False


def _close_x_hits(thr):
    """Matches of the red X, using the full saved picture and just the red button itself
    (without the background around it, which can look different)."""
    l, t, r, b = CLOSE_REGION
    bgr = _to_bgr(grab(CLOSE_REGION))
    full = _tpl("close")
    inner = full[7:-7, 7:-7]
    hits = _find_icon(bgr, "close", thr=thr) + _find_icon(bgr, "close", thr=thr, base=inner)
    hits.sort(reverse=True)
    return [(sc, l + x, t + y) for sc, x, y, _ in hits]


def shop_close_button():
    """Screen coords of the shop's red X if the shop is open, else None."""
    hits = _close_x_hits(0.75)
    return (hits[0][1], hits[0][2]) if hits else None


def shop_is_open():
    """The shop counts as open if its red X is visible, or if cash/gem buy buttons are.
    (The rebirth menu has a red X in the same area, so that doesn't count.)"""
    if _rebirth_button():
        return False
    if shop_close_button():
        return True
    return len(find_shop_buttons()) >= 2


def _open_shop():
    for attempt in range(1, 4):
        if shop_is_open():
            return True
        print(f"  pressing E to open the shop (try {attempt})")
        focus_roblox() if AUTO_FOCUS else None
        time.sleep(0.3)
        _send_scancode(OPEN_KEY_SCANCODE, hold=0.3)
        # Wait for it to actually open before pressing E again (a 2nd press can close it)
        end = time.time() + OPEN_WAIT
        while time.time() < end:
            time.sleep(0.7)
            if shop_is_open():
                time.sleep(0.8)          # let the items finish loading in
                return True
        if not shop_prompt_visible():
            print("  Selene's prompt is gone (did she leave, or did you move?)")
            return False
    return shop_is_open()


def _close_shop():
    for _ in range(3):
        pos = shop_close_button()
        if not pos:
            return not shop_is_open()
        _hover(pos[0], pos[1])
        _click()
        time.sleep(0.8)
    return not shop_is_open()


_OUT_WORDS = ("outofstock", "soldout")
_OWNED_WORDS = ("owned",)


def _stock_region(x, y):
    l, t, r, b = STOCK_REGION_OFFSET
    return (x + l, y + t, x + r, y + b)


def _stock_texts(x, y):
    """OCR readings of the bottom of the item card whose cash/gem icon is at (x, y).
    The stock text is coloured (red/orange/green) with a black outline, so besides plain
    grey it's also read as "bright coloured pixels" and as "the black outline"."""
    img = grab(_stock_region(x, y))
    big = img.resize((img.width * 2, img.height * 2), Image.LANCZOS)
    arr = np.array(big.convert("RGB")).astype(int)
    mx, mn = arr.max(axis=2), arr.min(axis=2)
    gray = big.convert("L")
    variants = (
        Image.fromarray(np.where((mx > 200) & (mx - mn > 110), 0, 255).astype("uint8")),  # bright colour text
        Image.fromarray(np.where(mx < 40, 0, 255).astype("uint8")),                         # black outline
        gray,
    )
    return [pytesseract.image_to_string(v, config="--psm 6").lower() for v in variants]


def _says_out_of_stock(text):
    """'Out of stock' / 'Sold out', allowing for a misread letter or two."""
    letters = re.sub(r"[^a-z]", "", _clean_ocr(text))
    for w in _OUT_WORDS:
        if w in letters:
            return True
        L = len(w)
        for i in range(0, len(letters) - L + 1):          # same-length windows only
            if difflib.SequenceMatcher(None, letters[i:i + L], w).ratio() >= 0.88:
                return True
    return False


def _stock_left(text):
    """A stock count shown on the item ("Stock: 3", "3 left", "3 in stock"), or None."""
    t = text.lower()             # raw text: the digit fix-ups in _clean_ocr would break numbers
    for pat in (r"st[o0]ck\s*[:x]?\s*(\d{1,3})", r"(\d{1,3})\s*(?:left|in\s*st[o0]ck)", r"x\s*(\d{1,3})\s*st[o0]ck"):
        m = re.search(pat, t)
        if m:
            return int(m.group(1))
    return None


def _says_owned(text):
    letters = re.sub(r"[^a-z]", "", _clean_ocr(text))
    return "owned" in letters


def stock_status(x, y):
    """('out', None) if out of stock / already owned, ('left', n) if a count is shown, else ('ok', None)."""
    if not STOCK_CHECK:
        return "ok", None
    texts = _stock_texts(x, y)
    if any(_says_out_of_stock(t) for t in texts):
        return "out", None
    if any(_says_owned(t) for t in texts):
        return "out", None
    for t in texts:
        n = _stock_left(t)
        if n is not None:
            return ("out", None) if n == 0 else ("left", n)
    return "ok", None


def _gray_region():
    return cv2.cvtColor(_to_bgr(grab(SHOP_REGION)), cv2.COLOR_BGR2GRAY).astype(np.int16)


def run_shop():
    """Open Selene's store, buy everything that costs cash or gems, close it. Never spends Robux."""
    with my_turn("shopping at Selene"):
        return _run_shop()


def _run_shop():
    old_pos = pyautogui.position()
    if _rebirth_button():
        print("  the rebirth menu was left open, closing it first")
        focus_roblox() if AUTO_FOCUS else None
        _close_rebirth_menu()
    if not _open_shop():
        print("  couldn't open the shop (are you standing next to Selene?)")
        return False
    print("  shop open")
    l, t, r, b = SHOP_REGION
    cx, cy = (l + r) // 2, (t + b) // 2
    seen, clicks = [], 0

    for pas in range(1, SHOP_PASSES + 1):
        _hover(cx, cy)
        _scroll(SCROLL_TOP_CLICKS)            # all the way back to the top of the list
        time.sleep(1.2)
        for step in range(MAX_SCROLL_STEPS + 1):
            for kind, x, y, sc, clickx in find_shop_buttons():
                if clicks >= MAX_CLICKS_PER_VISIT:
                    break
                if kind not in ("cash", "gem"):
                    continue                  # hard guarantee: nothing else is ever clicked
                sig = _button_sig(x, y)
                if any(int((sig != s2).sum()) <= 25 for s2 in seen):
                    continue                  # already bought this one
                if not _still_there(kind, x, y):
                    continue                  # moved/hidden (scrolling or text overlay), try later
                status, left = stock_status(x, y)
                if status == "out":
                    print(f"  pass {pas}: {kind} item at ({clickx},{y}) is out of stock, skipping")
                    seen.append(sig)
                    continue
                todo = BUY_CLICKS if left is None else min(BUY_CLICKS, left)
                print(f"  pass {pas}: buying {kind} button at ({clickx},{y})"
                      + (f"  ({left} in stock)" if left is not None else ""))
                _hover(clickx, y)
                done = 0
                for _ in range(todo):
                    _click()
                    clicks += 1
                    done += 1
                    time.sleep(BUY_CLICK_DELAY)
                    if done >= todo or clicks >= MAX_CLICKS_PER_VISIT:
                        break
                    if not _still_there(kind, x, y):
                        print(f"    button changed after {done} click(s): sold out")
                        break
                    if stock_status(x, y)[0] == "out":
                        print(f"    out of stock after {done} click(s)")
                        break
                seen.append(sig)
            before = _gray_region()
            _hover(cx, cy)
            _scroll(-SCROLL_NOTCHES)
            time.sleep(1.0)
            if np.abs(_gray_region() - before).mean() < 3:
                break                         # list stopped moving: reached the bottom
    print(f"  done: {clicks} clicks on cash/gem buttons")
    if not _close_shop():
        print("  couldn't confirm the shop closed - close it manually if it's still open")
    pyautogui.moveTo(old_pos.x, old_pos.y, duration=0.2)
    return True


def shop_sample():
    """Run this with the shop OPEN. Saves debug_shop.png with every button the script found."""
    img = grab(SHOP_REGION)
    canvas = _to_bgr(img)
    l, t, _, _ = SHOP_REGION
    print(f"prompt visible          : {shop_prompt_visible()}")
    hits = _close_x_hits(0.0)
    best = f"best match {hits[0][0]:.2f} at ({hits[0][1]},{hits[0][2]}), needs 0.75" if hits else "no match at all"
    print(f"close button (red X)    : {shop_close_button()}   [{best}]")
    print(f"shop counts as open     : {shop_is_open()}")
    cl, ct, cr, cb = CLOSE_REGION
    xs = _to_bgr(grab(CLOSE_REGION))
    if hits:
        cv2.circle(xs, (hits[0][1] - cl, hits[0][2] - ct), 12, (0, 255, 0) if hits[0][0] >= 0.75 else (0, 0, 255), 3)
    cv2.imwrite("debug_close.png", xs)
    print("Saved debug_close.png: the area searched for the red X (circle = best guess; green = accepted).")
    buttons = find_shop_buttons()
    print(f"cash/gem buttons found  : {len(buttons)}")
    for kind, x, y, sc, clickx in buttons:
        status, left = stock_status(x, y)
        stock_txt = {"out": "OUT OF STOCK", "left": f"{left} in stock", "ok": "in stock"}[status]
        print(f"  {kind:4s} icon ({x},{y}) -> will click ({clickx},{y}) score={sc:.2f}  stock: {stock_txt}")
        rl, rt, rr, rb = _stock_region(x, y)
        cv2.rectangle(canvas, (rl - l, rt - t), (rr - l, rb - t), (0, 255, 255), 1)    # yellow = stock area
        col = (255, 200, 0) if kind == "gem" else (0, 255, 0)
        cv2.rectangle(canvas, (x - l - 22, y - t - 20), (x - l + 118, y - t + 20), col, 2)
        cv2.circle(canvas, (clickx - l, y - t), 6, (0, 0, 255), -1)   # red dot = where it clicks
    cv2.imwrite("debug_shop.png", canvas)
    print("Saved debug_shop.png. Red dots (the click points) should sit inside cash ($) and gem buttons only, never Robux.")
    print("Yellow boxes = where it reads 'out of stock'. Each should cover that item's button (and the text")
    print("just above it) without reaching into a neighbouring item. Adjust STOCK_REGION_OFFSET if not.")



# ======================= ROBLOX PURCHASE POP-UP (safety) =======================
# Roblox's own "Buy item" / "Buy Robux and item" pop-up, recognised by its look (dark panel +
# wide bright-blue Buy button), so names and prices don't matter. Only its X is ever clicked.
_POP_REF_W = 416.0
_POP_X_TPL = cv2.imdecode(np.frombuffer(base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAABcAAAAWCAIAAACkFJBSAAAB8UlEQVQ4EaXBsU7bQBwH4N8/DnsY75YbsENy6atUEQuI2IezgFpV0AdoywBiLm0HVDrUzsVBZEP0VTiH2OkrkLmJk0pIlhIlmfx9xLhAYcS4QGHEuEBhxLhAYcS4QK7ZfPvx7PT45N1o9Bcb2PbO7c+br9ffHx//IEeMC+Qc2+737yaTfy33KE1HWOHYdhSF5fLW/sFhmo6QI8YFFrxpNDqd31k2bbl+kiRY4DhOLwotq6xU+8kYLCDGBZY1pNQ6yLKp6/nDYYJX1arTizqlkqVU+8kYLCPGBVY0pNQ6mM0y1/Ofn4e12m5XB6WS5SnfmBgriHGBdaSsax1gPr+4vDr/8glESrWNibEOMS6wgZR1rYPtSuVlPPY8P44H2IAYF9igXq91u+F2pfIyHnueH8cDbECMC6wjZV3rAPP5xeXV+flnAJ7nx/EA6xDjAiukrHd1OJtlnmoPBs+12m7UDUGkVNuYGCuIcYFlDSm1DmazrOUeDYcJXlWrTi/qlEqWp3xjYiwjxgUWNKTUOsiyacv1kyTBAsdxelFoWWWl2k/GYAExLpCz7Z3+/d10OnFdP0lTrHBsO4rCcnlr/+AwTUfIEeMCub295tnph+OT92k6wga2vfPr9ub624+Hh0fkiHGBwohxgcKIcYHCiHGBwv4DGBS/I7OIacgAAAAASUVORK5CYII="), np.uint8), cv2.IMREAD_COLOR)


def _screen_bgr():
    return _to_bgr(grab((0, 0, 1920, 1080)))


def _pop_panel_frac(img, x0, x1, y0, y1):
    reg = img[max(0, y0):max(0, y1), max(0, x0):max(0, x1)].astype(np.int16)
    if reg.size == 0:
        return 0.0
    mx, mn = reg.max(axis=2), reg.min(axis=2)
    return float(((mx <= 58) & (mx - mn <= 14)).mean())


def purchase_buy_button(img):
    """(x, y, w, h) of the pop-up's blue Buy button if Roblox's purchase pop-up is open, else None."""
    b, g, r = (img[:, :, i].astype(np.int16) for i in range(3))
    mask = ((b >= 215) & (g >= 65) & (g <= 130) & (r >= 20) & (r <= 95)).astype(np.uint8)
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    H, W = img.shape[:2]
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if w < W * 0.12 or h < 10 or not (5.0 <= w / h <= 16.0) or area < 0.75 * w * h:
            continue
        if (_pop_panel_frac(img, x, x + w, y - int(w * 0.25), y - 4) >= 0.45 and
                _pop_panel_frac(img, x, x + w, y + h + 2, y + h + max(6, int(w * 0.04))) >= 0.45):
            return int(x), int(y), int(w), int(h)
    return None


def purchase_popup_open():
    return purchase_buy_button(_screen_bgr()) is not None


def _pop_match_x(img, x0, y0, x1, y1, scale):
    H, W = img.shape[:2]
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
    best = (0.0, 0, 0)
    for f in (0.9, 1.0, 1.1):
        t = cv2.resize(_POP_X_TPL, None, fx=scale * f, fy=scale * f)
        sub = img[y0:y1, x0:x1]
        if t.shape[0] < 6 or sub.shape[0] < t.shape[0] or sub.shape[1] < t.shape[1]:
            continue
        _, sc, _, loc = cv2.minMaxLoc(cv2.matchTemplate(sub, t, cv2.TM_CCOEFF_NORMED))
        if sc > best[0]:
            best = (float(sc), x0 + loc[0] + t.shape[1] // 2, y0 + loc[1] + t.shape[0] // 2)
    return best


def purchase_popup_close_xy(img=None):
    """Screen position of the purchase pop-up's X, or None."""
    img = _screen_bgr() if img is None else img
    btn = purchase_buy_button(img)
    if not btn:
        return None
    H, W = img.shape[:2]
    bx, by, bw, bh = btn
    scale = bw / _POP_REF_W
    ym = by + bh // 2
    ref = img[ym, min(W - 1, bx + bw + max(2, int(4 * scale)))].astype(np.int16)
    same = lambda px: int(np.abs(px.astype(np.int16) - ref).max()) <= 5
    right = bx + bw
    while right + 1 < W and same(img[ym, right + 1]):
        right += 1
    col = max(0, right - max(3, int(8 * scale)))
    top, gap, y = by - 1, 0, by - 1
    while y > 0 and gap <= max(3, int(5 * scale)):
        if same(img[y, col]):
            top, gap = y, 0
        else:
            gap += 1
        y -= 1
    ex, ey = int(right - 31 / _POP_REF_W * bw), int(top + 27.5 / _POP_REF_W * bw)
    pad = max(12, int(bw * 0.07))
    sc, cx, cy = _pop_match_x(img, ex - pad, ey - pad, ex + pad, ey + pad, scale)
    if sc >= 0.6:
        return cx, cy
    sc, cx, cy = _pop_match_x(img, bx + int(bw * 0.6), by - int(bw * 0.75), right + pad, by, scale)
    return (cx, cy) if sc >= 0.7 else None


def close_purchase_popup():
    """Close Roblox's purchase pop-up with its X. Never clicks Buy. True when it's gone."""
    for _ in range(3):
        if not purchase_popup_open():
            return True
        xy = purchase_popup_close_xy()
        if not xy:
            break
        _hover(*xy)
        _click()
        time.sleep(1.0)
    if purchase_popup_open():
        print("  !! a Robux pop-up is open and its X wasn't found. Close it yourself (NEVER press Buy).")
        return False
    return True


# ======================= AUTO REBIRTH =======================
def _rebirth_button():
    """Centre of the green "Rebirth!" button if the rebirth menu is open, else None."""
    l, t, r, b = REBIRTH_BTN_REGION
    hits = _find_icon(_to_bgr(grab(REBIRTH_BTN_REGION)), "rebirth_btn", thr=0.75,
                      scales=(0.85, 0.92, 1.0, 1.08, 1.15))
    return (l + hits[0][1], t + hits[0][2]) if hits else None


def _sacrifice_unlocked():
    """The menu says "Reach 250 Rebirths to unlock SACRIFICE!" until you reach 250.
    If that line can't be read, treat it as unlocked and leave rebirthing to you."""
    img = grab(SACRIFICE_TEXT_REGION)
    big = img.resize((img.width * 2, img.height * 2), Image.LANCZOS)
    arr = np.array(big.convert("RGB")).astype(int)
    mx, mn = arr.max(axis=2), arr.min(axis=2)
    for v in (Image.fromarray(np.where((mx > 180) & (mx - mn > 100), 0, 255).astype("uint8")),
              Image.fromarray(np.where(mx < 40, 0, 255).astype("uint8")),
              big.convert("L")):
        letters = re.sub(r"[^a-z]", "", _clean_ocr(pytesseract.image_to_string(v, config="--psm 7")))
        if _fuzzy_in(letters, "rebirths") or _fuzzy_in(letters, "unlock") or _fuzzy_in(letters, "reach"):
            return False
    return True


def _close_rebirth_menu():
    for _ in range(2):
        if not _rebirth_button():
            return True
        pos = shop_close_button()
        if not pos:
            break
        _hover(*pos)
        _click()
        time.sleep(0.8)
    return _rebirth_button() is None


def run_rebirth():
    """Open the rebirth menu and press "Rebirth!". If there isn't enough cash the game opens
    Roblox's "Skip Rebirth" Robux pop-up, which gets closed with its X. Returns a short result."""
    with my_turn("rebirthing"):
        return _run_rebirth()


def _run_rebirth():
    old_pos = pyautogui.position()
    focus_roblox() if AUTO_FOCUS else None
    time.sleep(0.4)
    try:
        if purchase_popup_open():
            print("  a Robux pop-up was already open, closing it first")
            if not close_purchase_popup():
                return "stuck"
        if not _rebirth_button() and shop_is_open():
            print("  Selene's shop was left open, closing it first")
            if not _close_shop():
                return "shop still open"
        if not _rebirth_button():
            side = _find_icon(_to_bgr(grab((0, 330, 160, 540))), "rebirth_side", thr=0.6)
            x, y = (side[0][1], 330 + side[0][2]) if side else REBIRTH_SIDE_BUTTON
            _hover(x, y)
            _click()
            end = time.time() + 5
            while time.time() < end and not _rebirth_button():
                time.sleep(0.4)
        btn = _rebirth_button()
        if not btn:
            print("  rebirth menu didn't open (is something else in the way?), will try next time")
            return "no menu"
        if _sacrifice_unlocked():
            print("  the 'Reach 250 Rebirths to unlock SACRIFICE!' line is gone: sacrifice may be unlocked.")
            print("  Not rebirthing automatically - do this one yourself.")
            _close_rebirth_menu()
            return "sacrifice"
        _hover(*btn)
        _click()
        result = "rebirthed"
        end = time.time() + REBIRTH_POPUP_WAIT
        while time.time() < end:
            time.sleep(0.4)
            if purchase_popup_open():
                result = "not enough cash"
                close_purchase_popup()
                break
        time.sleep(0.5)
        _close_rebirth_menu()
        return result
    finally:
        pyautogui.moveTo(old_pos.x, old_pos.y, duration=0.2)


def advance_slot(current):
    """The mutation landed on `current`. Move to the next hotbar slot, unless it's a potion
    (or the hotbar ended). Returns (new_current_slot, all_done)."""
    nxt = current + 1
    if nxt > 10 or slot_is_potion(nxt):
        why = "end of the hotbar" if nxt > 10 else f"slot {nxt} is a potion"
        print(f"  {why}: all characters done, putting slot {current} away")
        if slot_outlined_blue(current)[0]:
            press_slot(current)
        return current, True
    print(f"  moving on to slot {nxt}")
    press_slot(nxt)
    if not slot_outlined_blue(nxt)[0]:
        print(f"  couldn't hold slot {nxt} (empty?): stopping here")
        if slot_outlined_blue(current)[0]:
            press_slot(current)
        return nxt, True
    return nxt, False


def main():
    modes = []
    if REBIRTH_ENABLED:
        modes.append(f"rebirth every {REBIRTH_EVERY // 60} min")
    if HALLOWS_ENABLED:
        modes.append("Hallow's Eve / Ada")
    if SHOP_ENABLED:
        modes.append("Selene's store")
    print(f"Running: {' + '.join(modes) or 'nothing enabled'}. Ctrl+C to stop.")
    last_shop = 0.0
    last_prompt_check = 0.0
    last_heartbeat = 0.0
    current = FIRST_SLOT          # hotbar slot of the character currently being mutated
    all_done = False
    next_rebirth = time.time() + REBIRTH_FIRST_AFTER
    event_on = False              # confirmed state (changes only after EVENT_CONFIRM_READS in a row)
    ev_votes = 0
    mut_streak = 0
    last_mut_check = 0.0
    while True:
        started = time.time()
        try:
            if REBIRTH_ENABLED and started >= next_rebirth:
                print(f"[{time.strftime('%H:%M:%S')}] checking rebirth...")
                result = run_rebirth()
                msg = {"rebirthed": "rebirthed! (no 'not enough cash' pop-up appeared)",
                       "not enough cash": "not enough cash yet (closed the Skip Rebirth pop-up)",
                       "sacrifice": "auto rebirth stopped: sacrifice may be unlocked, rebirth yourself",
                       }.get(result, result)
                print(f"  rebirth: {msg}. Next check in {REBIRTH_EVERY // 60} min.")
                next_rebirth = time.time() + (REBIRTH_EVERY if result != "sacrifice" else 10 ** 9)
                continue
            if (SHOP_ENABLED and started - last_shop > SHOP_COOLDOWN
                    and started - last_prompt_check >= SHOP_CHECK_EVERY):
                last_prompt_check = started
                if shop_prompt_visible():
                    print(f"[{time.strftime('%H:%M:%S')}] Selene's store prompt seen")
                    ok = run_shop()
                    # on success wait out the cooldown; on failure retry in ~1 minute
                    last_shop = time.time() if ok else time.time() - SHOP_COOLDOWN + 60
                    continue
            if not HALLOWS_ENABLED:
                if started - last_heartbeat >= 60:
                    last_heartbeat = started
                    print(f"[{time.strftime('%H:%M:%S')}] waiting for Selene's store...")
                time.sleep(max(0.2, CHECK_INTERVAL - (time.time() - started)))
                continue
            if all_done:
                if started - last_heartbeat >= 60:
                    last_heartbeat = started
                    print(f"[{time.strftime('%H:%M:%S')}] all characters done (restart the script to run again)")
                time.sleep(max(0.2, CHECK_INTERVAL - (time.time() - started)))
                continue
            reading, why = event_active()
            stamp = time.strftime("%H:%M:%S")
            if reading != event_on:
                ev_votes += 1
                if ev_votes >= EVENT_CONFIRM_READS:
                    event_on, ev_votes = reading, 0
                    if reading:
                        print(f"[{stamp}] Hallow's Eve STARTED  ({why})")
                    else:
                        print(f"[{stamp}] Hallow's Eve ended")
                elif reading:
                    print(f"[{stamp}] possible Hallow's Eve, confirming...  ({why})")
            else:
                ev_votes = 0
            ev = event_on
            eq, frac = slot_outlined_blue(current)
            print(f"[{stamp}] event={ev} slot={current} held={eq} (blue={frac:.2f})")

            if ev and not eq:
                print(f"  -> Event on, holding slot {current}")
                press_slot(current)
                mut_streak = 0
            elif not ev and eq:
                print(f"  -> Event off, putting slot {current} away")
                press_slot(current)
                mut_streak = 0
            elif ev and eq and started - last_mut_check >= MUTATION_CHECK_EVERY:
                last_mut_check = started
                present = mutation_seen(current)
                mut_streak = mut_streak + 1 if present else 0
                if mut_streak >= MUTATION_CONFIRM_READS:
                    mut_streak = 0
                    print(f"  -> '{MUTATION_WORD}' mutation seen on slot {current}!")
                    current, all_done = advance_slot(current)
        except pyautogui.FailSafeException:
            print("Failsafe triggered, stopping.")
            break
        time.sleep(max(0.2, CHECK_INTERVAL - (time.time() - started)))


if __name__ == "__main__":
    if "--sample" in sys.argv:
        sample()
    elif "--mutation-sample" in sys.argv:
        i = sys.argv.index("--mutation-sample")
        mutation_sample(sys.argv[i + 1] if i + 1 < len(sys.argv) and not sys.argv[i + 1].startswith("--") else None)
    elif "--shop-sample" in sys.argv:
        shop_sample()
    elif "--shop-now" in sys.argv:
        run_shop()
    elif "--rebirth-now" in sys.argv:
        print("rebirth:", run_rebirth())
    else:
        if "--shop-only" in sys.argv:
            HALLOWS_ENABLED = False
        if "--hallows-only" in sys.argv:
            SHOP_ENABLED = False
        if "--no-rebirth" in sys.argv:
            REBIRTH_ENABLED = False
        try:
            main()
        except KeyboardInterrupt:
            print("Stopped.")
