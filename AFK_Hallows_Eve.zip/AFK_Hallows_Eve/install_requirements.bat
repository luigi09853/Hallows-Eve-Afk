@echo off
setlocal
title AFK Hallow's Eve - installer
cd /d "%~dp0"
echo ================================================
echo   Installing everything afk_hallows_eve.py needs
echo ================================================
echo.

rem ---------- 1. Python ----------
call :find_python
if defined PY goto have_python

echo [1/3] Python was not found. Trying to install it with winget...
where winget 1>NUL 2>&1
if errorlevel 1 goto no_winget_python
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
echo.
echo Python was installed. CLOSE this window and double-click install_requirements.bat again
echo so Windows picks up the new Python.
pause
exit /b

:no_winget_python
echo Could not install Python automatically.
echo Download it from https://www.python.org/downloads/
echo IMPORTANT: on the first installer screen tick "Add python.exe to PATH".
echo Then run this file again.
start "" "https://www.python.org/downloads/"
pause
exit /b

:have_python
echo [1/3] Python found: %PY%
%PY% --version
echo.

rem ---------- 2. Python packages ----------
echo [2/3] Installing Python packages...
%PY% -m pip install --upgrade pip
%PY% -m pip install --upgrade mss pillow pyautogui pytesseract opencv-python numpy
if errorlevel 1 goto pip_failed
echo.

rem ---------- 3. Tesseract OCR ----------
set "TESS=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "%TESS%" goto have_tess
echo [3/3] Tesseract OCR not found. Trying to install it with winget...
where winget 1>NUL 2>&1
if errorlevel 1 goto no_winget_tess
winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements
if exist "%TESS%" goto have_tess

:no_winget_tess
echo.
echo Could not install Tesseract automatically.
echo Download the Windows installer from https://github.com/UB-Mannheim/tesseract/wiki
echo and install it to the default folder: C:\Program Files\Tesseract-OCR
start "" "https://github.com/UB-Mannheim/tesseract/wiki"
echo Then run this file again to check everything.
pause
exit /b

:have_tess
echo [3/3] Tesseract OCR found.
"%TESS%" --version 2>&1 | findstr /b "tesseract"
echo.

rem ---------- check ----------
echo Checking everything loads...
%PY% -c "import mss, PIL, pyautogui, pytesseract, cv2, numpy; pytesseract.pytesseract.tesseract_cmd=r'%TESS%'; print('OCR test:', 'ok' if pytesseract.get_tesseract_version() else 'failed')"
if errorlevel 1 goto check_failed
echo.
echo ================================================
echo   All done! Run the script with:
echo     python afk_hallows_eve.py --sample
echo   first, to check it lines up with your screen.
echo ================================================
pause
exit /b

:pip_failed
echo.
echo Installing the Python packages failed. Take a screenshot of the error above.
pause
exit /b

:check_failed
echo.
echo Something didn't load. Take a screenshot of the error above.
pause
exit /b

rem ---------- helper: find a working Python ----------
:find_python
set "PY="
py -3 --version 1>NUL 2>&1
if not errorlevel 1 set "PY=py -3"& goto :eof
python --version 1>NUL 2>&1
if not errorlevel 1 set "PY=python"& goto :eof
goto :eof
