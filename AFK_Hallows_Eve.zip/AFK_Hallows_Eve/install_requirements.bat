@echo off
setlocal
title AFK Hallow's Eve - installer
cd /d "%~dp0"
echo ================================================
echo   Installing everything afk_hallows_eve.py needs
echo ================================================
echo.

rem ---------- 1. Python ----------
call :find_python
if defined PY goto have_python

echo [1/3] Python was not found. Trying to install it with winget...
where winget 1>NUL 2>&1
if errorlevel 1 goto no_winget_python
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
echo.
echo Python was installed. CLOSE this window and double-click install_requirements.bat again
echo so Windows picks up the new Python.
pause
exit /b

:no_winget_python
echo Could not install Python automatically.
echo Download it from https://www.python.org/downloads/
echo IMPORTANT: on the first installer screen tick "Add python.exe to PATH".
echo Then run this file again.
start "" "https://www.python.org/downloads/"
pause
exit /b

:have_python
echo [1/3] Python found: %PY%
%PY% --version
echo.

rem ---------- 2. Python packages ----------
echo [2/3] Installing Python packages: mss, pillow, pyautogui, pytesseract, opencv-python, numpy
set "PKGS=mss pillow pyautogui pytesseract opencv-python numpy"
%PY% -m pip install --upgrade --timeout 30 %PKGS%
if not errorlevel 1 goto pip_ok
echo.
echo Normal download failed or was too slow. Trying the Tsinghua mirror in China...
%PY% -m pip install --upgrade --timeout 30 -i https://pypi.tuna.tsinghua.edu.cn/simple %PKGS%
if not errorlevel 1 goto pip_ok
echo.
echo Trying the Aliyun mirror...
%PY% -m pip install --upgrade --timeout 30 -i https://mirrors.aliyun.com/pypi/simple/ %PKGS%
:pip_ok
echo.
echo Checking the Python packages...
%PY% -c "import importlib.util as u,sys;bad=[m for m in ('mss','PIL','pyautogui','pytesseract','cv2','numpy') if u.find_spec(m) is None];print('  MISSING Python packages: '+', '.join(bad) if bad else '  all 6 Python packages OK');sys.exit(1 if bad else 0)"
if errorlevel 1 goto pip_failed
echo.

rem ---------- 3. Tesseract OCR (the text-reading PROGRAM, separate from pytesseract) ----------
call :find_tess
if defined TESS goto have_tess
echo [3/3] Tesseract OCR program not found. Trying to install it with winget...
echo       (Windows may ask for permission - click Yes)
where winget 1>NUL 2>&1
if errorlevel 1 goto no_tess
winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements
call :find_tess
if defined TESS goto have_tess

:no_tess
echo.
echo Could not find or install the Tesseract OCR program.
echo Download the Windows installer (tesseract-ocr-w64-setup...exe) from:
echo   https://github.com/UB-Mannheim/tesseract/wiki
echo Install it with the default settings, then run this file again.
start "" "https://github.com/UB-Mannheim/tesseract/wiki"
pause
exit /b

:have_tess
echo [3/3] Tesseract OCR program found:
echo       %TESS%
echo.

rem ---------- English language file (eng.traineddata) ----------
for %%d in ("%TESS%") do set "TESSDIR=%%~dpd"
if exist "%TESSDIR%tessdata\eng.traineddata" goto lang_tess
if exist "%~dp0tessdata\eng.traineddata" goto lang_ours
echo Tesseract's English language file (eng.traineddata) is missing, and the copy that
echo comes with this script (tessdata folder) isn't here either. Re-extract the zip.
goto check_failed
:lang_tess
set "TESSDATA_PREFIX=%TESSDIR%tessdata"
echo English language file: Tesseract's own copy
goto lang_done
:lang_ours
set "TESSDATA_PREFIX=%~dp0tessdata"
echo English language file: using the copy in this folder (Tesseract's own copy is missing)
:lang_done
echo.

rem ---------- final check: actually read some text ----------
echo Checking Tesseract can read text...
%PY% -c "import sys,pytesseract;from PIL import Image,ImageDraw;pytesseract.pytesseract.tesseract_cmd=sys.argv[1];im=Image.new('RGB',(320,60),'white');ImageDraw.Draw(im).text((10,10),'TEST 123',fill='black',font_size=32);print('  read:',repr(pytesseract.image_to_string(im,config='--psm 7').strip()),'- OK')" "%TESS%"
if errorlevel 1 goto check_failed
echo.
echo ================================================
echo   All done! Run the script with:
echo     double-click start.bat and pick 5 (test)
echo   first, to check it lines up with your screen.
echo ================================================
pause
exit /b

:pip_failed
echo.
echo Some Python packages are missing (listed above). Take a screenshot of this window.
pause
exit /b

:check_failed
echo.
echo Tesseract couldn't read text. Take a screenshot of this window.
pause
exit /b

rem ---------- helper: find a working Python ----------
:find_python
set "PY="
py -3 --version 1>NUL 2>&1
if not errorlevel 1 set "PY=py -3"& goto :eof
python --version 1>NUL 2>&1
if not errorlevel 1 set "PY=python"& goto :eof
goto :eof

rem ---------- helper: find tesseract.exe wherever it was installed ----------
:find_tess
set "TESS="
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" set "TESS=%ProgramFiles%\Tesseract-OCR\tesseract.exe"& goto :eof
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" set "TESS=%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe"& goto :eof
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESS=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"& goto :eof
if exist "%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe" set "TESS=%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe"& goto :eof
for /f "delims=" %%i in ('where tesseract 2^>NUL') do set "TESS=%%i"& goto :eof
goto :eof
